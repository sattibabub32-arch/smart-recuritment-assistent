import React, { useState } from "react";
import { User, Shield, Key, Mail, Building, Briefcase, Eye, EyeOff, Brain, CheckCircle, ArrowLeft } from "lucide-react";
import { motion } from "motion/react";

interface AuthProps {
  onAuthSuccess: (token: string, user: any) => void;
  onNavigate: (view: string) => void;
  initialMode?: "login" | "register" | "forgot" | "reset";
}

export default function Auth({ onAuthSuccess, onNavigate, initialMode = "login" }: AuthProps) {
  const [mode, setMode] = useState<"login" | "register" | "forgot" | "reset">(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  
  // Form fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"Candidate" | "Recruiter">("Candidate");
  const [company, setCompany] = useState("");
  const [designation, setDesignation] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  const resetMessages = () => {
    setError("");
    setInfo("");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Authentication failed. Check your credentials.");
      }

      onAuthSuccess(data.token, data.user);
      setInfo("Login successful! Redirecting...");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          password,
          role,
          company: role === "Recruiter" ? company : undefined,
          designation: role === "Recruiter" ? designation : undefined,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Registration failed. Check details.");
      }

      onAuthSuccess(data.token, data.user);
      setInfo("Account registered successfully! Loading Dashboard...");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    try {
      const res = await fetch("/api/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Unable to send reset instructions.");

      setInfo(data.message);
      // Automatically shift to reset mode for ease of local prototyping!
      setTimeout(() => setMode("reset"), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    try {
      const res = await fetch("/api/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, newPassword }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Password reset failed.");

      setInfo("Password reset successfully! Shifting to login panel...");
      setTimeout(() => {
        setMode("login");
        resetMessages();
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden font-sans">
      {/* Decorative Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-purple-600/10 blur-3xl"></div>

      <div className="max-w-md w-full relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="mx-auto w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 mb-4 cursor-pointer" onClick={() => onNavigate("home")}>
            <Brain className="w-7 h-7" />
          </div>
          <h2 className="text-3xl font-black text-white tracking-tight">
            {mode === "login" && "Welcome Back"}
            {mode === "register" && "Create Candidate Account"}
            {mode === "forgot" && "Recover Account"}
            {mode === "reset" && "Set New Password"}
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            {mode === "login" && "Access your smart recruiter workspace"}
            {mode === "register" && "Step into the future of automated screening"}
            {mode === "forgot" && "Reset your portal security configurations"}
            {mode === "reset" && "Establish secure workspace password keys"}
          </p>
        </div>

        {/* Card Body */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-8 backdrop-blur-xl shadow-2xl">
          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs font-semibold leading-relaxed">
              {error}
            </div>
          )}

          {info && (
            <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{info}</span>
            </div>
          )}

          {/* Login Form */}
          {mode === "login" && (
            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="name@company.com"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider">Password</label>
                  <button type="button" onClick={() => setMode("forgot")} className="text-xs text-indigo-400 hover:underline">Forgot password?</button>
                </div>
                <div className="relative">
                  <Key className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-10 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3.5 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-sm text-white shadow-lg shadow-indigo-500/25 disabled:opacity-50 hover:shadow-indigo-500/35 transition-all flex justify-center"
              >
                {loading ? "Authenticating Portal..." : "Sign In"}
              </button>
            </form>
          )}

          {/* Register Form */}
          {mode === "register" && (
            <form onSubmit={handleRegister} className="space-y-5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="Jane Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="jane@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Select Portal Role</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setRole("Candidate")}
                    className={`p-3.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                      role === "Candidate"
                        ? "bg-indigo-500/10 border-indigo-500 text-indigo-300 shadow-lg shadow-indigo-500/10"
                        : "bg-slate-950 border-white/10 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <User className="w-5 h-5" />
                    <span className="text-xs font-bold font-mono">Candidate</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRole("Recruiter")}
                    className={`p-3.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                      role === "Recruiter"
                        ? "bg-indigo-500/10 border-indigo-500 text-indigo-300 shadow-lg shadow-indigo-500/10"
                        : "bg-slate-950 border-white/10 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <Building className="w-5 h-5" />
                    <span className="text-xs font-bold font-mono">Recruiter</span>
                  </button>
                </div>
              </div>

              {role === "Recruiter" && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Company Name</label>
                    <div className="relative">
                      <Building className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="text"
                        required
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                        placeholder="Quantum Inc."
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Designation</label>
                    <div className="relative">
                      <Briefcase className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                      <input
                        type="text"
                        required
                        value={designation}
                        onChange={(e) => setDesignation(e.target.value)}
                        className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                        placeholder="Lead Talent Acquisition"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Create Security Password</label>
                <div className="relative">
                  <Key className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-10 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3.5 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-sm text-white shadow-lg shadow-indigo-500/25 disabled:opacity-50 hover:shadow-indigo-500/35 transition-all flex justify-center"
              >
                {loading ? "Registering Workspace..." : "Create Account"}
              </button>
            </form>
          )}

          {/* Forgot Password */}
          {mode === "forgot" && (
            <form onSubmit={handleForgot} className="space-y-5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Registered Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-slate-500" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="jane@example.com"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-sm text-white shadow-lg shadow-indigo-500/25 disabled:opacity-50 hover:shadow-indigo-500/35 transition-all flex justify-center"
              >
                {loading ? "Searching Directory..." : "Send Reset Link"}
              </button>
            </form>
          )}

          {/* Reset Password */}
          {mode === "reset" && (
            <form onSubmit={handleReset} className="space-y-5">
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Registered Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                  placeholder="jane@example.com"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Enter New Security Password</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                  placeholder="••••••••"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-sm text-white shadow-lg shadow-indigo-500/25 disabled:opacity-50 hover:shadow-indigo-500/35 transition-all flex justify-center"
              >
                {loading ? "Overwriting Secrets..." : "Reset Password"}
              </button>
            </form>
          )}

          {/* Bottom Switcher Nav */}
          <div className="mt-6 pt-6 border-t border-white/10 flex justify-between text-xs font-semibold font-mono">
            {mode === "login" ? (
              <>
                <span className="text-slate-400">Don't have an account?</span>
                <button onClick={() => { setMode("register"); resetMessages(); }} className="text-indigo-400 hover:underline">Register</button>
              </>
            ) : (
              <>
                <button onClick={() => { setMode("login"); resetMessages(); }} className="text-slate-400 hover:text-white flex items-center gap-1">
                  <ArrowLeft className="w-3 h-3" />
                  <span>Back to login</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Back Link */}
        <div className="text-center mt-6">
          <button onClick={() => onNavigate("home")} className="text-xs font-semibold text-slate-500 hover:text-slate-300 flex items-center justify-center gap-1 mx-auto">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Go Back to Landing Page</span>
          </button>
        </div>
      </div>
    </div>
  );
}
