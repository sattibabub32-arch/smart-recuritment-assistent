import React, { useState } from "react";
import { 
  Briefcase, UploadCloud, Award, TrendingUp, Users, CheckCircle, 
  Brain, Shield, ChevronRight, Star, Mail, Phone, MapPin, Menu, X, Terminal
} from "lucide-react";
import { motion } from "motion/react";

interface HomeProps {
  onNavigate: (view: string) => void;
  isAuthenticated: boolean;
  userRole?: string;
  onLogout: () => void;
}

export default function Home({ onNavigate, isAuthenticated, userRole, onLogout }: HomeProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [contactForm, setContactForm] = useState({ name: "", email: "", msg: "" });
  const [contactSuccess, setContactSuccess] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (contactForm.name && contactForm.email && contactForm.msg) {
      setContactSuccess(true);
      setContactForm({ name: "", email: "", msg: "" });
      setTimeout(() => setContactSuccess(false), 4000);
    }
  };

  const handleActionClick = () => {
    if (isAuthenticated) {
      if (userRole === "Candidate") onNavigate("candidate-dashboard");
      else if (userRole === "Recruiter") onNavigate("recruiter-dashboard");
      else onNavigate("admin-dashboard");
    } else {
      onNavigate("login");
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans">
      {/* 1. Header & Navigation */}
      <nav id="app-nav" className="sticky top-0 z-50 bg-[#0e121a]/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-lg text-white shadow-lg shadow-indigo-500/20">
                <Brain className="w-6 h-6" />
              </div>
              <div>
                <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400 text-lg tracking-wider">
                  SMART RECRUIT
                </span>
                <span className="block text-[10px] font-mono text-slate-400 tracking-widest uppercase">AI Assistant</span>
              </div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm font-medium text-slate-300 hover:text-indigo-400 transition-colors">Features</a>
              <a href="#how-it-works" className="text-sm font-medium text-slate-300 hover:text-indigo-400 transition-colors">How It Works</a>
              <a href="#stats" className="text-sm font-medium text-slate-300 hover:text-indigo-400 transition-colors">Statistics</a>
              <a href="#testimonials" className="text-sm font-medium text-slate-300 hover:text-indigo-400 transition-colors">Testimonials</a>
              <a href="#contact" className="text-sm font-medium text-slate-300 hover:text-indigo-400 transition-colors">Contact</a>
            </div>

            {/* Auth Actions */}
            <div className="hidden md:flex items-center gap-4">
              {isAuthenticated ? (
                <>
                  <button 
                    onClick={handleActionClick}
                    className="px-4 py-2 bg-[#0e121a] text-slate-200 text-sm font-semibold rounded-lg hover:bg-white/[0.05] transition-all border border-white/5"
                  >
                    Dashboard
                  </button>
                  <button 
                    onClick={onLogout}
                    className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-600 text-white text-sm font-semibold rounded-lg hover:opacity-90 transition-all shadow-md shadow-red-500/10"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <button 
                    onClick={() => onNavigate("login")}
                    className="text-sm font-semibold text-slate-300 hover:text-white transition-colors"
                  >
                    Sign In
                  </button>
                  <button 
                    onClick={() => onNavigate("register")}
                    className="px-4 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-lg hover:bg-indigo-500 hover:shadow-indigo-500/25 hover:shadow-lg transition-all"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-slate-400 hover:text-white p-2"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu panel */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#0e121a] border-b border-white/10 py-4 px-6 space-y-3">
            <a href="#features" onClick={() => setMobileMenuOpen(false)} className="block text-slate-300 hover:text-indigo-400 py-1 text-sm font-medium">Features</a>
            <a href="#how-it-works" onClick={() => setMobileMenuOpen(false)} className="block text-slate-300 hover:text-indigo-400 py-1 text-sm font-medium">How It Works</a>
            <a href="#stats" onClick={() => setMobileMenuOpen(false)} className="block text-slate-300 hover:text-indigo-400 py-1 text-sm font-medium">Statistics</a>
            <a href="#testimonials" onClick={() => setMobileMenuOpen(false)} className="block text-slate-300 hover:text-indigo-400 py-1 text-sm font-medium">Testimonials</a>
            <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="block text-slate-300 hover:text-indigo-400 py-1 text-sm font-medium">Contact</a>
            <div className="pt-4 border-t border-white/5 flex flex-col gap-3">
              {isAuthenticated ? (
                <>
                  <button 
                    onClick={() => { setMobileMenuOpen(false); handleActionClick(); }}
                    className="w-full py-2 bg-white/[0.05] text-center rounded-lg text-sm font-medium"
                  >
                    Dashboard
                  </button>
                  <button 
                    onClick={() => { setMobileMenuOpen(false); onLogout(); }}
                    className="w-full py-2 bg-red-600 text-center rounded-lg text-sm font-medium text-white"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <button 
                    onClick={() => { setMobileMenuOpen(false); onNavigate("login"); }}
                    className="w-full py-2 text-center text-sm font-medium text-slate-300"
                  >
                    Sign In
                  </button>
                  <button 
                    onClick={() => { setMobileMenuOpen(false); onNavigate("register"); }}
                    className="w-full py-2 bg-indigo-600 text-center rounded-lg text-sm font-medium text-white hover:bg-indigo-500"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* 2. Hero Section */}
      <header className="relative py-24 sm:py-32 overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#0b0e14] via-[#0e121a] to-[#0b0e14]">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-indigo-500/20 bg-indigo-500/10 text-indigo-300 text-xs font-mono mb-8"
          >
            <Terminal className="w-3.5 h-3.5 animate-pulse" />
            <span>AI-POWERED CANDIDATE SCREENING PLATFORM v2.5</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl sm:text-6xl font-black tracking-tight text-white max-w-4xl mx-auto leading-none mb-6"
          >
            Empower Your Hiring with <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-500 to-indigo-500">
              Smart Machine Learning
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-base sm:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Smart Recruitment Assistant parses resumes using Gemini AI, computes 
            skills affinity scores using Cosine Similarity, and predicts candidate fitness via advanced ML models.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row justify-center items-center gap-4"
          >
            <button 
              onClick={handleActionClick}
              className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/20 hover:scale-[1.01] transition-all flex items-center justify-center gap-2"
            >
              <span>Launch Platform</span>
              <ChevronRight className="w-5 h-5" />
            </button>
            <a 
              href="#how-it-works"
              className="w-full sm:w-auto px-8 py-4 bg-[#0e121a] border border-white/5 text-slate-300 font-bold rounded-xl hover:bg-white/[0.05] hover:text-white transition-all text-center"
            >
              See How It Works
            </a>
          </motion.div>
        </div>
      </header>

      {/* 3. Features Section */}
      <section id="features" className="py-24 bg-[#0b0e14]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-mono uppercase tracking-widest text-indigo-400 mb-2">Advanced Modules</h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-white">Automate the Entire Funnel with ML</p>
            <p className="text-slate-400 mt-4 text-sm sm:text-base">Built with robust scikit-learn models, cosine text vectors, and Google's Gemini LLMs.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feat 1 */}
            <div className="p-8 bg-white/[0.03] rounded-2xl border border-white/10 hover:border-indigo-500/30 hover:-translate-y-1 transition-all">
              <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl w-fit mb-6">
                <UploadCloud className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">AI Resume Parsing</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Natively accepts PDF, DOCX, and TXT. Extracts full structured JSON containing name, contact details, certifications, skills, education, and career experience.
              </p>
              <span className="text-xs font-mono text-indigo-400">Gemini 3.5 Flash Parser</span>
            </div>

            {/* Feat 2 */}
            <div className="p-8 bg-white/[0.03] rounded-2xl border border-white/10 hover:border-indigo-500/30 hover:-translate-y-1 transition-all">
              <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl w-fit mb-6">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Vector Match & TF-IDF</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Utilizes mathematical Term Frequency - Inverse Document Frequency indexers and Cosine Similarity to compare candidate skill footprints directly against recruiter requests.
              </p>
              <span className="text-xs font-mono text-purple-400">Cosine TF-IDF Vectorizer</span>
            </div>

            {/* Feat 3 */}
            <div className="p-8 bg-white/[0.03] rounded-2xl border border-white/10 hover:border-indigo-500/30 hover:-translate-y-1 transition-all">
              <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl w-fit mb-6">
                <Brain className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Logistic Classifier</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Uses our custom trained Logistic Regression ML classifier to calculate the likelihood of shortlisting and outputs discrete "Selected" or "Rejected" decisions.
              </p>
              <span className="text-xs font-mono text-blue-400">Logistic Regression</span>
            </div>
          </div>
        </div>
      </section>

      {/* 4. How It Works */}
      <section id="how-it-works" className="py-24 bg-[#0e121a]/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-mono uppercase tracking-widest text-indigo-400 mb-2">Pipeline</h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-white">How It Works</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            {/* Step 1 */}
            <div className="text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-white/5 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-black text-lg mb-4">1</div>
              <h4 className="font-bold text-white mb-2">Upload Profile</h4>
              <p className="text-slate-400 text-xs">Candidates register and upload standard PDF or text resumes to parse properties.</p>
            </div>
            {/* Step 2 */}
            <div className="text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-white/5 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-black text-lg mb-4">2</div>
              <h4 className="font-bold text-white mb-2">Post Requirements</h4>
              <p className="text-slate-400 text-xs">Recruiters input role profiles, required tech skills, and target years of experience.</p>
            </div>
            {/* Step 3 */}
            <div className="text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-white/5 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-black text-lg mb-4">3</div>
              <h4 className="font-bold text-white mb-2">Matching & ML</h4>
              <p className="text-slate-400 text-xs">System calculates Cosine Similarity score, extracts skills overlap, and runs ML prediction.</p>
            </div>
            {/* Step 4 */}
            <div className="text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-white/5 border border-indigo-500/30 text-indigo-400 flex items-center justify-center font-black text-lg mb-4">4</div>
              <h4 className="font-bold text-white mb-2">Screening Decision</h4>
              <p className="text-slate-400 text-xs">Recruiters view applicants sorted by match percentage, downloading parsed results.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Platform Statistics */}
      <section id="stats" className="py-20 bg-[#080b11] border-t border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">98%</p>
              <p className="text-slate-400 text-xs sm:text-sm font-medium mt-2">Parsing Accuracy</p>
            </div>
            <div>
              <p className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">1.2s</p>
              <p className="text-slate-400 text-xs sm:text-sm font-medium mt-2">Average Match Speed</p>
            </div>
            <div>
              <p className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">5k+</p>
              <p className="text-slate-400 text-xs sm:text-sm font-medium mt-2">Skills Indexed</p>
            </div>
            <div>
              <p className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">100%</p>
              <p className="text-slate-400 text-xs sm:text-sm font-medium mt-2">Automated Tracking</p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Testimonials */}
      <section id="testimonials" className="py-24 bg-[#0b0e14]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-mono uppercase tracking-widest text-indigo-400 mb-2">Success Stories</h2>
            <p className="text-3xl font-extrabold text-white">Loved by HR & Recruiting Leaders</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Testimonial 1 */}
            <div className="p-8 bg-white/[0.03] rounded-2xl border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex gap-1 text-amber-500 mb-4">
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <p className="text-slate-300 text-sm italic leading-relaxed mb-6">
                  "Before using Smart Recruit, our HR managers spent days reading hundreds of candidate files. With Gemini's structured resume parser and the ML scoring engine, the system ranks the top 5 match candidates automatically. We decreased screen timeline by 85%!"
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-sm">ES</div>
                <div>
                  <h5 className="font-bold text-white text-sm">Eleanor Sterling</h5>
                  <p className="text-xs text-slate-500">Head of Talent at CloudScale Technologies</p>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="p-8 bg-white/[0.03] rounded-2xl border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex gap-1 text-amber-500 mb-4">
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <p className="text-slate-300 text-sm italic leading-relaxed mb-6">
                  "The skill matching matrix and the Cosine similarity scorecard are absolute lifesavers. I can visually inspect missing and matched skills directly in the table view and download candidates' parsed specifications. A truly incredible full-stack platform."
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm">MK</div>
                <div>
                  <h5 className="font-bold text-white text-sm">Marcus Vance</h5>
                  <p className="text-xs text-slate-500">Lead Recruiting Partner at Quantum Solutions</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Contact Section */}
      <section id="contact" className="py-24 bg-[#0e121a]/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-xs font-mono uppercase tracking-widest text-indigo-400 mb-2">Get In Touch</h2>
              <p className="text-3xl font-extrabold text-white mb-6">Talk to Our AI Recruiting Experts</p>
              <p className="text-slate-400 text-sm sm:text-base leading-relaxed mb-8">
                Have questions about our Logistic Regression models, Gemini prompt extraction, or enterprise pricing tiers? Submit your request and we will respond within 24 hours.
              </p>

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#0e121a] rounded-xl border border-white/5 text-indigo-400"><Mail className="w-5 h-5" /></div>
                  <span className="text-sm text-slate-300">support@smartrecruit.ai</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#0e121a] rounded-xl border border-white/5 text-indigo-400"><Phone className="w-5 h-5" /></div>
                  <span className="text-sm text-slate-300">+1 (555) 019-2831</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#0e121a] rounded-xl border border-white/5 text-indigo-400"><MapPin className="w-5 h-5" /></div>
                  <span className="text-sm text-slate-300">Silicon Valley, CA</span>
                </div>
              </div>
            </div>

            <div className="p-8 bg-[#0e121a] rounded-2xl border border-white/10 relative">
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Your Name</label>
                  <input 
                    type="text" 
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="Jane Doe"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                  <input 
                    type="email" 
                    required
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="jane@company.com"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Message</label>
                  <textarea 
                    rows={4}
                    required
                    value={contactForm.msg}
                    onChange={(e) => setContactForm({ ...contactForm, msg: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="How can we help you?"
                  ></textarea>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-sm font-bold text-white shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/35 transition-all"
                >
                  Send Inquiry
                </button>
              </form>

              {contactSuccess && (
                <div className="absolute inset-0 bg-[#0b0e14]/95 flex flex-col items-center justify-center p-8 text-center rounded-2xl">
                  <CheckCircle className="w-16 h-16 text-emerald-400 mb-4 animate-bounce" />
                  <h4 className="text-xl font-bold text-white mb-2">Message Received!</h4>
                  <p className="text-xs text-slate-400">Thank you for contacting Smart Recruitment Assistant. One of our specialists will be in touch shortly.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="mt-auto bg-[#080b11] border-t border-white/5 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/5 border border-white/10 rounded-lg text-indigo-400">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-white text-sm tracking-wider uppercase">SMART RECRUITMENT ASSISTANT</span>
              <p className="text-slate-600 text-[10px] font-mono uppercase mt-0.5">© 2026 Smart Recruit Platform. All rights reserved.</p>
            </div>
          </div>

          <div className="flex gap-6 text-xs text-slate-500 font-mono">
            <a href="#" className="hover:text-indigo-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-400 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-indigo-400 transition-colors">ML Parameters</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
