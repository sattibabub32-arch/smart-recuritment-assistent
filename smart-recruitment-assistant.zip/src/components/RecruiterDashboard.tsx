import React, { useState, useEffect } from "react";
import { 
  Briefcase, PlusCircle, FileText, Award, User, Trash2, Edit3, CheckCircle, 
  XCircle, Download, ChevronRight, MapPin, Eye, Brain, HelpCircle, AlertCircle, BarChart3
} from "lucide-react";
import { Job, Application, AnalyticsMetrics } from "../types";
import AnalyticsPanel from "./AnalyticsPanel";

interface RecruiterDashboardProps {
  token: string;
  user: any;
  onLogout: () => void;
  onNavigate: (view: string) => void;
}

export default function RecruiterDashboard({ token, user, onLogout, onNavigate }: RecruiterDashboardProps) {
  const [activeTab, setActiveTab] = useState<"rankings" | "jobs" | "post" | "analytics">("rankings");

  // State data
  const [myJobs, setMyJobs] = useState<Job[]>([]);
  const [applicants, setApplicants] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsMetrics | null>(null);

  // Job form state
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [jobTitle, setJobTitle] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [jobSkills, setJobSkills] = useState("");
  const [jobExp, setJobExp] = useState(2);
  const [jobSalary, setJobSalary] = useState("Competitive");
  const [jobLocation, setJobLocation] = useState("Remote");

  // Selection states
  const [selectedJobId, setSelectedJobId] = useState<string>("");
  const [viewingResume, setViewingResume] = useState<string | null>(null); // Plaintext candidate resume viewer modal
  const [selectedApplicant, setSelectedApplicant] = useState<any | null>(null);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchMyJobs = async () => {
    try {
      const res = await fetch("/api/jobs");
      const data = await res.json();
      if (res.ok) {
        // Filter jobs posted by this recruiter
        const filtered = data.filter((j: Job) => j.postedBy === user._id);
        setMyJobs(filtered);
        if (filtered.length > 0 && !selectedJobId) {
          setSelectedJobId(filtered[0]._id);
        }
      }
    } catch (e) {}
  };

  const fetchApplicants = async () => {
    try {
      const res = await fetch("/api/applications", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) setApplicants(data);
    } catch (e) {}
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch("/api/analytics", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) setAnalytics(data);
    } catch (e) {}
  };

  useEffect(() => {
    fetchMyJobs();
    fetchApplicants();
    fetchAnalytics();
  }, [token]);

  // Post or edit Job
  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const method = editingJob ? "PUT" : "POST";
      const payload = editingJob 
        ? { _id: editingJob._id, title: jobTitle, description: jobDesc, requiredSkills: jobSkills, experience: jobExp, salary: jobSalary, location: jobLocation }
        : { title: jobTitle, description: jobDesc, requiredSkills: jobSkills, experience: jobExp, salary: jobSalary, location: jobLocation };

      const res = await fetch("/api/jobs", {
        method,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed listing job opening.");

      setSuccess(editingJob ? "Job opening updated successfully!" : "Job listed successfully on the portal!");
      setEditingJob(null);
      resetJobForm();
      fetchMyJobs();
      fetchAnalytics();
      setTimeout(() => {
        setActiveTab("jobs");
        setSuccess("");
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const resetJobForm = () => {
    setJobTitle("");
    setJobDesc("");
    setJobSkills("");
    setJobExp(2);
    setJobSalary("Competitive");
    setJobLocation("Remote");
  };

  const handleEditJobClick = (job: Job) => {
    setEditingJob(job);
    setJobTitle(job.title);
    setJobDesc(job.description);
    setJobSkills(job.requiredSkills.join(", "));
    setJobExp(job.experience);
    setJobSalary(job.salary);
    setJobLocation(job.location);
    setActiveTab("post");
  };

  const handleDeleteJob = async (jobId: string) => {
    if (!window.confirm("Are you sure you want to delete this job listing and all associated applications?")) return;
    setError("");
    setSuccess("");

    try {
      const res = await fetch(`/api/jobs?id=${jobId}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed deleting job.");

      setSuccess("Job listing deleted successfully.");
      fetchMyJobs();
      fetchApplicants();
      fetchAnalytics();
      setTimeout(() => setSuccess(""), 4000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Update applicant status (Shortlist/Reject)
  const handleStatusChange = async (appId: string, status: "Shortlisted" | "Rejected") => {
    setError("");
    setSuccess("");

    try {
      const res = await fetch("/api/applications", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ id: appId, status })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed updating applicant status.");

      setSuccess(`Applicant successfully ${status.toLowerCase()}!`);
      
      // Update local states immediately
      setApplicants(applicants.map(app => app._id === appId ? { ...app, status } : app));
      if (selectedApplicant && selectedApplicant._id === appId) {
        setSelectedApplicant({ ...selectedApplicant, status });
      }
      fetchAnalytics();
      setTimeout(() => setSuccess(""), 4000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Filter applicants based on selected job opening and sort by match score
  const activeApplicants = applicants
    .filter((app) => app.jobId === selectedJobId)
    .sort((a, b) => b.score - a.score); // Match Score Ranking!

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* 1. Sidebar Nav */}
      <aside className="w-full md:w-64 bg-[#0e121a] border-b md:border-b-0 md:border-r border-white/10 flex flex-col shrink-0">
        <div className="p-6 border-b border-white/10 flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg text-white"><Briefcase className="w-5 h-5" /></div>
          <div>
            <span className="font-extrabold text-white text-sm tracking-wide block uppercase">Recruiter Deck</span>
            <span className="text-[10px] text-indigo-400 font-mono tracking-widest">{user?.name}</span>
          </div>
        </div>

        <nav className="p-4 flex-1 space-y-1.5">
          <button
            onClick={() => { setActiveTab("rankings"); setSelectedApplicant(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "rankings"
                ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.05] hover:text-white"
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Rank Candidates</span>
          </button>

          <button
            onClick={() => { setActiveTab("jobs"); setSelectedApplicant(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "jobs"
                ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.05] hover:text-white"
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>My Job Openings</span>
          </button>

          <button
            onClick={() => { setActiveTab("post"); setEditingJob(null); resetJobForm(); setSelectedApplicant(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "post"
                ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.05] hover:text-white"
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Post New Job</span>
          </button>

          <button
            onClick={() => { setActiveTab("analytics"); setSelectedApplicant(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "analytics"
                ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.05] hover:text-white"
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Recruit Metrics</span>
          </button>
        </nav>

        <div className="p-4 border-t border-white/10 flex flex-col gap-2">
          <button onClick={() => onNavigate("home")} className="text-xs text-slate-500 hover:text-slate-300 font-mono text-center">Home Landing Page</button>
          <button 
            onClick={onLogout}
            className="w-full py-2.5 bg-black/40 border border-white/10 text-slate-300 rounded-xl hover:bg-red-950/30 hover:text-red-400 hover:border-red-900/35 text-xs font-bold transition-all"
          >
            Sign Out Desk
          </button>
        </div>
      </aside>

      {/* 2. Main Desk Frame */}
      <main className="flex-1 p-6 sm:p-10 overflow-y-auto">
        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs font-semibold leading-relaxed">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs font-semibold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* TAB 1: RANK CANDIDATES */}
        {activeTab === "rankings" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h2 className="text-2xl font-black text-white">Smart Match & Rankings</h2>
                <p className="text-slate-400 text-xs">Candidates automatically sorted by neural skills overlap and academic suitability.</p>
              </div>

              {/* Job dropdown selector */}
              {myJobs.length > 0 && (
                <div className="bg-[#0e121a] border border-white/10 rounded-xl p-1 shrink-0 w-full sm:w-auto">
                  <select
                    value={selectedJobId}
                    onChange={(e) => { setSelectedJobId(e.target.value); setSelectedApplicant(null); }}
                    className="bg-transparent border-none text-xs text-slate-300 font-bold px-4 py-2 focus:outline-none appearance-none cursor-pointer w-full focus:ring-0"
                  >
                    {myJobs.map((j) => (
                      <option key={j._id} value={j._id} className="bg-[#0b0e14]">{j.title}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {myJobs.length === 0 ? (
              <div className="p-16 border border-white/10 rounded-3xl bg-white/[0.02] text-center">
                <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                <h3 className="text-white font-bold text-base mb-1">No Active Job Postings</h3>
                <p className="text-slate-500 text-xs mb-6">Create a job opening to evaluate incoming applications.</p>
                <button onClick={() => setActiveTab("post")} className="px-5 py-2.5 bg-indigo-600 rounded-xl font-bold text-xs text-white hover:bg-indigo-500 transition-colors">Post New Job</button>
              </div>
            ) : selectedApplicant ? (
              /* APPLICANT SCREENING REPORT VIEW */
              <div className="bg-white/[0.03] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 animate-fadeIn">
                <button 
                  onClick={() => setSelectedApplicant(null)}
                  className="text-xs font-mono text-indigo-400 hover:underline flex items-center gap-1"
                >
                  ← Return to Rankings Table
                </button>

                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-white/10 pb-6 gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedApplicant.candidateName}</h3>
                    <p className="text-xs text-slate-400 font-mono mt-1">{selectedApplicant.candidateEmail} • {selectedApplicant.candidateExperience} Years of Exp</p>
                  </div>

                  <div className="flex gap-4 items-center w-full sm:w-auto justify-between">
                    <div className="text-center bg-black/40 px-4 py-3 rounded-xl border border-white/10 shrink-0">
                      <span className="text-[10px] text-slate-500 font-mono block uppercase">Match Score</span>
                      <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">{selectedApplicant.score}%</span>
                    </div>

                    <div className="text-center bg-black/40 px-4 py-3 rounded-xl border border-white/10 shrink-0">
                      <span className="text-[10px] text-slate-500 font-mono block uppercase">ML Recommendation</span>
                      <span className={`text-xs font-black block uppercase mt-1 ${
                        selectedApplicant.analysis?.prediction === "Selected" ? "text-emerald-400" : "text-red-400"
                      }`}>{selectedApplicant.analysis?.prediction || "Applied"}</span>
                    </div>

                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleStatusChange(selectedApplicant._id, "Shortlisted")}
                        className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-white rounded-xl transition-all"
                        title="Shortlist Applicant"
                      >
                        <CheckCircle className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => handleStatusChange(selectedApplicant._id, "Rejected")}
                        className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition-all"
                        title="Reject Applicant"
                      >
                        <XCircle className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Resume Download / View */}
                <div className="p-4 bg-black/40 border border-white/10 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-slate-400 shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-white block">Download Full Parsed Resume Specification</span>
                      <p className="text-[10px] text-slate-500 font-mono uppercase mt-0.5">TXT format available for localized review</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setViewingResume(selectedApplicant.resumeText)}
                    className="px-4 py-2 bg-[#0e121a] hover:bg-white/[0.05] border border-white/10 rounded-xl text-xs font-bold text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download/View</span>
                  </button>
                </div>

                {/* Gemini Profiling Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <h4 className="text-sm font-bold font-mono text-indigo-400 border-b border-indigo-950/50 pb-2 uppercase tracking-wider">Candidate Skills Coverage</h4>
                    
                    <div>
                      <span className="text-xs font-bold text-emerald-400 block mb-2">Matched Requirements</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedApplicant.analysis?.skillsMatch && selectedApplicant.analysis.skillsMatch.length > 0 ? (
                          selectedApplicant.analysis.skillsMatch.map((s: string, idx: number) => (
                            <span key={idx} className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg text-xs font-mono">{s}</span>
                          ))
                        ) : (
                          <span className="text-slate-500 text-xs italic">No direct required overlaps extracted.</span>
                        )}
                      </div>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-red-400 block mb-2">Missing Skills Matrix</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedApplicant.analysis?.skillsMissing && selectedApplicant.analysis.skillsMissing.length > 0 ? (
                          selectedApplicant.analysis.skillsMissing.map((s: string, idx: number) => (
                            <span key={idx} className="px-2.5 py-1 bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg text-xs font-mono">{s}</span>
                          ))
                        ) : (
                          <span className="text-emerald-400 text-xs italic font-mono">100% Core Requirements Matched!</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-sm font-bold font-mono text-indigo-400 border-b border-indigo-950/50 pb-2 uppercase tracking-wider">AI Assessment Audit</h4>
                    
                    <div>
                      <span className="text-[10px] text-slate-500 font-mono uppercase block">Experience Critique</span>
                      <p className="text-slate-300 text-xs mt-1.5 leading-relaxed">{selectedApplicant.analysis?.experienceEvaluation}</p>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 font-mono uppercase block">Academic Suitability</span>
                      <p className="text-slate-300 text-xs mt-1.5 leading-relaxed">{selectedApplicant.analysis?.educationEvaluation}</p>
                    </div>

                    <div className="p-4 bg-black/40 border border-white/10 rounded-xl flex gap-3">
                      <Brain className="w-5 h-5 text-indigo-400 shrink-0" />
                      <div>
                        <span className="text-xs font-bold text-indigo-400 font-mono block">Executive Summary</span>
                        <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">{selectedApplicant.analysis?.recommendation}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* APPLICANTS RANKING TABLE */
              <div className="bg-white/[0.02] border border-white/10 rounded-3xl overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-white/10 bg-black/40 text-slate-400 font-mono">
                        <th className="p-4">Rank Order</th>
                        <th className="p-4">Candidate Name</th>
                        <th className="p-4">Experience</th>
                        <th className="p-4">Matching Score</th>
                        <th className="p-4">ML Predict</th>
                        <th className="p-4">Final status</th>
                        <th className="p-4 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10">
                      {activeApplicants.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-12 text-center text-slate-500 italic">No submitted applications found for this opening yet.</td>
                        </tr>
                      ) : (
                        activeApplicants.map((app, index) => (
                           <tr key={app._id} className="hover:bg-white/[0.03] transition-colors">
                            <td className="p-4 text-center font-black text-slate-550 font-mono text-sm">#{index + 1}</td>
                            <td className="p-4 font-bold text-white">
                              <div>
                                <span className="block text-slate-200">{app.candidateName}</span>
                                <span className="block text-[10px] text-slate-500 font-mono mt-0.5">{app.candidateEmail}</span>
                              </div>
                            </td>
                            <td className="p-4 text-slate-300 font-mono font-bold">{app.candidateExperience} Years</td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <div className="w-20 bg-white/[0.05] h-2 rounded-full overflow-hidden border border-white/10">
                                  <div className="bg-gradient-to-r from-indigo-400 to-purple-500 h-full" style={{ width: `${app.score}%` }}></div>
                                </div>
                                <span className="font-mono font-bold text-slate-200">{app.score}%</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
                                app.analysis?.prediction === "Selected" ? "bg-emerald-950/50 text-emerald-400 border border-emerald-900" : "bg-black/40 text-slate-500 border border-white/10"
                              }`}>
                                {app.analysis?.prediction || "Applied"}
                              </span>
                            </td>
                            <td className="p-4">
                              <span className={`font-mono uppercase font-black text-[10px] ${
                                app.status === "Shortlisted" ? "text-emerald-400" : app.status === "Rejected" ? "text-red-400" : "text-slate-400"
                              }`}>
                                {app.status}
                              </span>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center justify-center gap-2">
                                <button 
                                  onClick={() => setSelectedApplicant(app)}
                                  className="px-3 py-1.5 bg-black/40 hover:bg-white/[0.05] border border-white/10 text-indigo-400 hover:text-white font-bold rounded-lg transition-colors"
                                >
                                  View Audit
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MY JOB OPENINGS */}
        {activeTab === "jobs" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">My Active Listings</h2>
              <p className="text-slate-400 text-xs">Manage active job openings, edit parameters, and inspect metrics.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {myJobs.length === 0 ? (
                <div className="p-12 text-center border border-white/10 rounded-2xl bg-white/[0.02] col-span-2">
                  <p className="text-slate-500 text-sm">No job openings listed under your account. Post one above.</p>
                </div>
              ) : (
                myJobs.map((job) => (
                  <div key={job._id} className="p-6 bg-white/[0.03] border border-white/10 rounded-2xl flex flex-col justify-between hover:border-white/20 transition-all">
                    <div>
                      <div className="flex justify-between items-start gap-4 mb-2">
                        <h3 className="font-extrabold text-white text-base leading-snug">{job.title}</h3>
                        <span className="px-2.5 py-1 bg-black/40 border border-white/10 rounded-lg text-[10px] font-mono text-indigo-400 font-semibold">{job.location}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono mb-4">Salary: {job.salary}</p>
                      <p className="text-slate-300 text-xs leading-relaxed mb-4 line-clamp-3">{job.description}</p>
                      
                      <div className="flex flex-wrap gap-1.5 mb-6">
                        {job.requiredSkills.map((s, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-indigo-950/20 text-indigo-400 rounded border border-indigo-950/50 text-[10px] font-mono">{s}</span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                      <div className="text-xs">
                        <span className="text-slate-500">Exp Min: </span>
                        <span className="text-slate-300 font-bold font-mono">{job.experience} yrs</span>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditJobClick(job)}
                          className="p-2 bg-black/40 border border-white/10 hover:bg-white/[0.05] rounded-xl text-slate-300 hover:text-white transition-colors"
                          title="Edit Job Specifications"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteJob(job._id)}
                          className="p-2 bg-red-950/10 border border-red-950/20 hover:bg-red-900 text-red-400 hover:text-white rounded-xl transition-colors"
                          title="Delete Listing"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 3: POST / EDIT JOB */}
        {activeTab === "post" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">{editingJob ? "Edit Job Specifications" : "Post New Job Opening"}</h2>
              <p className="text-slate-400 text-xs">Define technical keywords, salary variables, and target years of experience.</p>
            </div>

            <form onSubmit={handlePostJob} className="bg-white/[0.03] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 max-w-3xl">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Job Opening Title</label>
                  <input
                    type="text"
                    required
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    placeholder="e.g. Lead Machine Learning Engineer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Geographic Location</label>
                  <select
                    value={jobLocation}
                    onChange={(e) => setJobLocation(e.target.value)}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-400 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Onsite">On-site</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Salary Estimate Range</label>
                  <input
                    type="text"
                    required
                    value={jobSalary}
                    onChange={(e) => setJobSalary(e.target.value)}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    placeholder="e.g. $140,000 - $180,000 / year"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Min Required Experience (Years)</label>
                  <input
                    type="number"
                    required
                    value={jobExp}
                    onChange={(e) => setJobExp(Number(e.target.value))}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Required Skills (Comma separated list)</label>
                  <input
                    type="text"
                    required
                    value={jobSkills}
                    onChange={(e) => setJobSkills(e.target.value)}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                    placeholder="Python, PyTorch, Scikit-learn, Pandas, NumPy, NLP"
                  />
                  <span className="text-[10px] text-slate-500 font-mono block mt-1.5">Directly mapped in match calculations. Separated with commas.</span>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Job Description Requirements</label>
                  <textarea
                    rows={6}
                    required
                    value={jobDesc}
                    onChange={(e) => setJobDesc(e.target.value)}
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl p-4 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 leading-relaxed"
                    placeholder="Join our engineering team to construct state of the art pipeline models..."
                  ></textarea>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-3.5 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl font-bold text-xs text-white hover:opacity-90 shadow-md shadow-indigo-500/20 cursor-pointer transition-all"
                >
                  {loading ? "Saving Opening..." : editingJob ? "Update Job Specifications" : "List Job Opening"}
                </button>
                <button
                  type="button"
                  onClick={() => { setEditingJob(null); resetJobForm(); setActiveTab("jobs"); }}
                  className="px-6 py-3.5 bg-black/40 border border-white/10 rounded-xl text-xs font-bold text-slate-400 hover:text-white cursor-pointer transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 4: RECRUITMENT METRICS */}
        {activeTab === "analytics" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">Recruiting Dashboards</h2>
              <p className="text-slate-400 text-xs">Visualize platform applicant volume, skills taxonomy density, and selection funnels.</p>
            </div>

            {analytics ? (
              <AnalyticsPanel metrics={analytics} />
            ) : (
              <p className="text-slate-500 text-xs italic">Loading analytical telemetry dashboard...</p>
            )}
          </div>
        )}
      </main>

      {/* 3. Plaintext resume viewer modal */}
      {viewingResume && (
        <div className="fixed inset-0 z-50 bg-[#0b0e14]/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e121a] border border-white/10 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-black/40">
              <div>
                <h4 className="font-bold text-white text-sm">Resume Document Plaintext Viewer</h4>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">Physical plaintext index representation</p>
              </div>
              <button 
                onClick={() => setViewingResume(null)}
                className="p-1.5 hover:bg-white/[0.05] border border-white/10 rounded-lg text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
              >
                Close Viewer
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 font-mono text-xs text-slate-300 leading-relaxed bg-[#0b0e14] whitespace-pre-wrap">
              {viewingResume}
            </div>

            <div className="p-4 border-t border-white/10 bg-[#0e121a] flex justify-end gap-3">
              {/* Mock Download TXT */}
              <button 
                onClick={() => {
                  const element = document.createElement("a");
                  const file = new Blob([viewingResume], {type: 'text/plain'});
                  element.href = URL.createObjectURL(file);
                  element.download = "candidate_parsed_resume.txt";
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                }}
                className="px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl font-bold text-xs text-white hover:opacity-90 transition-all cursor-pointer"
              >
                Download Resume TXT
              </button>
              <button 
                onClick={() => setViewingResume(null)}
                className="px-4 py-2 bg-black/40 border border-white/10 rounded-xl font-bold text-xs text-slate-400 hover:text-white cursor-pointer transition-colors"
              >
                Dismiss Viewer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
