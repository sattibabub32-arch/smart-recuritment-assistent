import React, { useState, useEffect } from "react";
import { 
  Briefcase, FileText, UploadCloud, Award, User, Settings, CheckCircle, 
  Trash2, PlusCircle, Search, MapPin, Filter, HelpCircle, ChevronRight, AlertTriangle, Cpu
} from "lucide-react";
import { Job, Application, CandidateDetails } from "../types";

interface CandidateDashboardProps {
  token: string;
  user: any;
  onLogout: () => void;
  onNavigate: (view: string) => void;
}

export default function CandidateDashboard({ token, user, onLogout, onNavigate }: CandidateDashboardProps) {
  const [activeTab, setActiveTab] = useState<"jobs" | "applications" | "profile" | "upload">("jobs");
  
  // Data lists
  const [jobs, setJobs] = useState<Job[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [profile, setProfile] = useState<any>(null);

  // Search & Filters
  const [search, setSearch] = useState("");
  const [filterLoc, setFilterLoc] = useState("");
  const [filterExp, setFilterExp] = useState("");

  // Upload/Paste state
  const [pasteText, setPasteText] = useState("");
  const [uploadLoading, setUploadLoading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Profile forms
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editEducation, setEditEducation] = useState("");
  const [editExperience, setEditExperience] = useState(0);
  const [skillInput, setSkillInput] = useState("");
  const [skills, setSkills] = useState<string[]>([]);
  const [certInput, setCertInput] = useState("");
  const [certs, setCerts] = useState<string[]>([]);
  const [langInput, setLangInput] = useState("");
  const [langs, setLangs] = useState<string[]>([]);
  
  // Projects list
  const [projects, setProjects] = useState<Array<{ title: string; description: string; technologies: string[] }>>([]);
  const [newProjTitle, setNewProjTitle] = useState("");
  const [newProjDesc, setNewProjDesc] = useState("");
  const [newProjTech, setNewProjTech] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [applyingJobId, setApplyingJobId] = useState<string | null>(null);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  const fetchJobs = async () => {
    try {
      const res = await fetch("/api/jobs");
      const data = await res.json();
      if (res.ok) setJobs(data);
    } catch (e) {}
  };

  const fetchApplications = async () => {
    try {
      const res = await fetch("/api/applications", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) setApplications(data);
    } catch (e) {}
  };

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/profile", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setProfile(data);
        setEditName(data.name);
        setEditEmail(data.email);
        setEditEducation(data.details?.education || "");
        setEditExperience(data.details?.experience || 0);
        setSkills(data.details?.skills || []);
        setCerts(data.details?.certifications || []);
        setLangs(data.details?.languages || []);
        setProjects(data.details?.projects || []);
      }
    } catch (e) {}
  };

  useEffect(() => {
    fetchJobs();
    fetchApplications();
    fetchProfile();
  }, [token]);

  // Handle Drag & Drop events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    if (!file) return;
    setUploadLoading(true);
    setError("");
    setUploadSuccess(false);

    try {
      // Convert file to Base64 and plain text approximation
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(",")[1];
        const mimeType = file.type;

        // Mock reading contents for standard text extraction approximation on client
        const fileTextApproximation = `
          ${file.name.replace(/\.[^/.]+$/, "")} Resume File
          Email: candidate@example.com
          Phone: (555) 019-2831
          Education: Bachelor of Science in Information Systems
          Experience: 4 years of experience as a systems dev.
          Skills: Python, JavaScript, TypeScript, React, HTML5, CSS3, Docker, PostgreSQL, AWS
          Projects: Portfolio Hub, Cloud Scaler
          Certifications: AWS Developer Associate
          Languages: English
        `;

        const res = await fetch("/api/upload_resume", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          body: JSON.stringify({
            base64File: base64Data,
            textContent: fileTextApproximation,
            mimeType: mimeType
          })
        });

        const result = await res.json();
        if (!res.ok) throw new Error(result.error || "Failed parsing resume file.");

        setUploadSuccess(true);
        setSuccess("File uploaded and analyzed by Gemini AI!");
        fetchProfile();
        setTimeout(() => {
          setActiveTab("profile");
          setUploadSuccess(false);
        }, 2000);
      };
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploadLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Submit copy pasted text
  const handlePasteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pasteText.trim()) return;
    setUploadLoading(true);
    setError("");

    try {
      const res = await fetch("/api/upload_resume", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          textContent: pasteText,
          mimeType: "text/plain"
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed parsing input text.");

      setUploadSuccess(true);
      setSuccess("Resume text successfully parsed!");
      setPasteText("");
      fetchProfile();
      setTimeout(() => {
        setActiveTab("profile");
        setUploadSuccess(false);
      }, 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploadLoading(false);
    }
  };

  // Save manual profile edits
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      const res = await fetch("/api/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          name: editName,
          email: editEmail,
          details: {
            education: editEducation,
            experience: editExperience,
            skills,
            certifications: certs,
            languages: langs,
            projects
          }
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Profile update failed.");

      setSuccess("Profile configurations updated successfully!");
      fetchProfile();
      setTimeout(() => setSuccess(""), 4000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Add Item arrays helpers
  const addSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const addCert = () => {
    if (certInput.trim() && !certs.includes(certInput.trim())) {
      setCerts([...certs, certInput.trim()]);
      setCertInput("");
    }
  };

  const removeCert = (index: number) => {
    setCerts(certs.filter((_, i) => i !== index));
  };

  const addLang = () => {
    if (langInput.trim() && !langs.includes(langInput.trim())) {
      setLangs([...langs, langInput.trim()]);
      setLangInput("");
    }
  };

  const removeLang = (index: number) => {
    setLangs(langs.filter((_, i) => i !== index));
  };

  const addProject = () => {
    if (newProjTitle.trim() && newProjDesc.trim()) {
      const techArray = newProjTech.split(",").map(t => t.trim()).filter(t => t.length > 0);
      setProjects([...projects, {
        title: newProjTitle.trim(),
        description: newProjDesc.trim(),
        technologies: techArray
      }]);
      setNewProjTitle("");
      setNewProjDesc("");
      setNewProjTech("");
    }
  };

  const removeProject = (index: number) => {
    setProjects(projects.filter((_, i) => i !== index));
  };

  // Apply for Job
  const handleApply = async (jobId: string) => {
    setApplyingJobId(jobId);
    setError("");
    setSuccess("");

    try {
      const res = await fetch("/api/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ jobId })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed submitting application. Check profile skills.");
      }

      setSuccess(`Applied successfully! Score: ${data.score}% | ML Outcome: ${data.mlPrediction.outcome}`);
      fetchApplications();
      setTimeout(() => setSuccess(""), 5000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setApplyingJobId(null);
    }
  };

  // Filtered Jobs List
  const filteredJobs = jobs.filter((job) => {
    const sTerm = search.toLowerCase();
    const titleMatch = job.title.toLowerCase().includes(sTerm);
    const descMatch = job.description.toLowerCase().includes(sTerm);
    const skillMatch = job.requiredSkills.some(s => s.toLowerCase().includes(sTerm));
    const locationMatch = filterLoc ? job.location.toLowerCase() === filterLoc.toLowerCase() : true;
    const experienceMatch = filterExp ? job.experience <= Number(filterExp) : true;

    return (titleMatch || descMatch || skillMatch) && locationMatch && experienceMatch;
  });

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-200 flex flex-col md:flex-row font-sans">
      
      {/* 1. Sidebar Panel */}
      <aside className="w-full md:w-64 bg-[#0e121a] border-b md:border-b-0 md:border-r border-white/10 flex flex-col shrink-0">
        <div className="p-6 border-b border-white/10 flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400"><User className="w-5 h-5" /></div>
          <div>
            <span className="font-extrabold text-white text-sm tracking-wide block uppercase">Candidate Desk</span>
            <span className="text-[10px] text-indigo-400 font-mono tracking-widest">{user?.name}</span>
          </div>
        </div>

        <nav className="p-4 flex-1 space-y-1.5">
          <button
            onClick={() => { setActiveTab("jobs"); setSelectedApp(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "jobs"
                ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.04] hover:text-white"
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span>Search Jobs</span>
          </button>

          <button
            onClick={() => { setActiveTab("applications"); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "applications"
                ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.04] hover:text-white"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>My Applications</span>
          </button>

          <button
            onClick={() => { setActiveTab("upload"); setSelectedApp(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "upload"
                ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.04] hover:text-white"
            }`}
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Resume</span>
          </button>

          <button
            onClick={() => { setActiveTab("profile"); setSelectedApp(null); }}
            className={`w-full py-3 px-4 rounded-xl font-medium text-sm flex items-center gap-3 transition-colors ${
              activeTab === "profile"
                ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                : "text-slate-400 hover:bg-white/[0.04] hover:text-white"
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Edit Profile</span>
          </button>
        </nav>

        <div className="p-4 border-t border-white/10 flex flex-col gap-2">
          <button onClick={() => onNavigate("home")} className="text-xs text-slate-500 hover:text-slate-300 font-mono text-center">Home Landing Page</button>
          <button 
            onClick={onLogout}
            className="w-full py-2.5 bg-slate-950 border border-white/10 text-slate-300 rounded-xl hover:bg-red-950/30 hover:text-red-400 hover:border-red-900/35 text-xs font-bold transition-all"
          >
            Sign Out Desk
          </button>
        </div>
      </aside>

      {/* 2. Main Content Grid */}
      <main className="flex-1 p-6 sm:p-10 overflow-y-auto">
        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs font-semibold leading-relaxed flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fadeIn">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* TAB 1: SEARCH JOBS */}
        {activeTab === "jobs" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">Smart Job Board</h2>
              <p className="text-slate-400 text-xs">Explore openings, match requirements, and submit parsed files.</p>
            </div>

            {/* Filters panel */}
            <div className="bg-white/[0.02] border border-white/10 rounded-2xl p-5 flex flex-col sm:flex-row gap-4 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-slate-950/40 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                  placeholder="Search by role title, skill name, keywords..."
                />
              </div>

              <div className="flex gap-4 w-full sm:w-auto">
                <div className="relative flex-1 sm:flex-initial">
                  <Filter className="absolute left-3 top-3 h-3.5 w-3.5 text-slate-500" />
                  <select
                    value={filterLoc}
                    onChange={(e) => setFilterLoc(e.target.value)}
                    className="bg-[#0e121a] border border-white/10 rounded-xl pl-9 pr-6 py-2.5 text-xs text-slate-400 focus:outline-none focus:border-indigo-500 appearance-none w-full"
                  >
                    <option value="">All Locations</option>
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Onsite">On-site</option>
                  </select>
                </div>

                <div className="relative flex-1 sm:flex-initial">
                  <Briefcase className="absolute left-3 top-3 h-3.5 w-3.5 text-slate-500" />
                  <select
                    value={filterExp}
                    onChange={(e) => setFilterExp(e.target.value)}
                    className="bg-[#0e121a] border border-white/10 rounded-xl pl-9 pr-6 py-2.5 text-xs text-slate-400 focus:outline-none focus:border-indigo-500 appearance-none w-full"
                  >
                    <option value="">All Experience</option>
                    <option value="1">Entry (1 yr max)</option>
                    <option value="3">Mid (3 yrs max)</option>
                    <option value="5">Senior (5 yrs max)</option>
                    <option value="8">Lead (8 yrs max)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Jobs list output */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredJobs.length === 0 ? (
                <div className="p-12 text-center border border-white/10 rounded-2xl bg-white/[0.01] col-span-2">
                  <p className="text-slate-500 text-sm">No job openings found matching your criteria.</p>
                </div>
              ) : (
                filteredJobs.map((job) => {
                  const alreadyApplied = applications.some((app) => app.jobId === job._id);
                  return (
                    <div key={job._id} className="p-6 bg-white/[0.02] border border-white/10 rounded-2xl flex flex-col justify-between hover:border-white/20 transition-all">
                      <div>
                        <div className="flex justify-between items-start gap-4 mb-2">
                          <h3 className="font-extrabold text-white text-base leading-snug">{job.title}</h3>
                          <span className="px-2.5 py-1 bg-[#0b0e14] border border-white/10 rounded-lg text-[10px] font-mono text-indigo-300 font-semibold">{job.location}</span>
                        </div>
                        <p className="text-xs text-slate-400 font-mono mb-4">{job.companyName} • {job.recruiterName}</p>
                        
                        <p className="text-slate-300 text-xs leading-relaxed mb-4 line-clamp-3">{job.description}</p>
                        
                        <div className="flex flex-wrap gap-1.5 mb-6">
                          {job.requiredSkills.map((s, idx) => (
                            <span key={idx} className="px-2 py-0.5 bg-indigo-500/5 text-indigo-300 rounded border border-indigo-500/10 text-[10px] font-mono">{s}</span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                        <div className="text-xs">
                          <span className="text-slate-500">Exp Req: </span>
                          <span className="text-slate-300 font-bold font-mono">{job.experience} yrs</span>
                        </div>

                        {alreadyApplied ? (
                          <span className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/25 rounded-lg text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>Applied Already</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => handleApply(job._id)}
                            disabled={applyingJobId !== null || !profile?.details?.skills?.length}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold text-xs shadow-md shadow-indigo-500/15 disabled:opacity-50 transition-all"
                          >
                            {applyingJobId === job._id ? "Evaluating..." : "Apply Instantly"}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* TAB 2: MY APPLICATIONS */}
        {activeTab === "applications" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">Application Matrix</h2>
              <p className="text-slate-400 text-xs">Review match scoring and predictive screening metrics.</p>
            </div>

            {selectedApp ? (
              <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 sm:p-8 space-y-6 animate-fadeIn">
                <button 
                  onClick={() => setSelectedApp(null)}
                  className="text-xs font-mono text-indigo-400 hover:underline flex items-center gap-1"
                >
                  ← Return to Applications List
                </button>

                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-white/10 pb-6 gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedApp.jobTitle}</h3>
                    <p className="text-xs text-slate-400 font-mono mt-1">{selectedApp.companyName}</p>
                  </div>

                  <div className="flex gap-4 items-center">
                    <div className="text-center bg-slate-950/45 p-3 rounded-xl border border-white/10">
                      <span className="text-[10px] text-slate-500 font-mono block uppercase">Match Score</span>
                      <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">{selectedApp.score}%</span>
                    </div>

                    <div className="text-center bg-slate-950/45 p-3 rounded-xl border border-white/10">
                      <span className="text-[10px] text-slate-500 font-mono block uppercase">ML Screen Status</span>
                      <span className={`text-xs font-black block uppercase mt-1 ${
                        selectedApp.status === "Shortlisted" ? "text-emerald-400" : selectedApp.status === "Rejected" ? "text-red-400" : "text-amber-400"
                      }`}>{selectedApp.status}</span>
                    </div>
                  </div>
                </div>

                {/* Gemini Screening Feedback */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-5">
                    <h4 className="text-sm font-bold font-mono text-indigo-400 border-b border-indigo-500/20 pb-2">Technical Skills Mapping</h4>
                    
                    <div>
                      <span className="text-xs font-semibold text-emerald-400 block mb-2">Matched Core Skills</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedApp.analysis?.skillsMatch && selectedApp.analysis.skillsMatch.length > 0 ? (
                          selectedApp.analysis.skillsMatch.map((s, idx) => (
                            <span key={idx} className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-xs font-mono">{s}</span>
                          ))
                        ) : (
                          <span className="text-slate-500 text-xs italic">No matched requirements highlighted.</span>
                        )}
                      </div>
                    </div>

                    <div>
                      <span className="text-xs font-semibold text-red-400 block mb-2">Missing Skills & Keywords</span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedApp.analysis?.skillsMissing && selectedApp.analysis.skillsMissing.length > 0 ? (
                          selectedApp.analysis.skillsMissing.map((s, idx) => (
                            <span key={idx} className="px-2.5 py-1 bg-red-500/10 border border-red-500/20 text-red-400 rounded text-xs font-mono">{s}</span>
                          ))
                        ) : (
                          <span className="text-emerald-400 text-xs italic">Complete skills coverage!</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-5">
                    <h4 className="text-sm font-bold font-mono text-indigo-400 border-b border-indigo-500/20 pb-2">AI Profiling Audit</h4>
                    
                    <div>
                      <span className="text-xs text-slate-400 font-mono block">Academic Assessment</span>
                      <p className="text-slate-300 text-xs mt-1 leading-relaxed">{selectedApp.analysis?.educationEvaluation}</p>
                    </div>

                    <div>
                      <span className="text-xs text-slate-400 font-mono block">Experience Suitability</span>
                      <p className="text-slate-300 text-xs mt-1 leading-relaxed">{selectedApp.analysis?.experienceEvaluation}</p>
                    </div>

                    <div className="p-4 bg-slate-950/40 border border-white/10 rounded-xl flex gap-3">
                      <Cpu className="w-5 h-5 text-indigo-400 shrink-0" />
                      <div>
                        <span className="text-xs text-indigo-400 font-mono font-bold block">AI Recruiter Summary</span>
                        <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">{selectedApp.analysis?.recommendation}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-white/10 bg-slate-950/80 text-slate-400 font-mono">
                        <th className="p-4">Position Title</th>
                        <th className="p-4">Company</th>
                        <th className="p-4">Match Score</th>
                        <th className="p-4">ML Predict</th>
                        <th className="p-4">Final status</th>
                        <th className="p-4">Audit report</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {applications.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-10 text-center text-slate-500 italic">No submitted applications yet. Apply for job postings above.</td>
                        </tr>
                      ) : (
                        applications.map((app) => (
                          <tr key={app._id} className="hover:bg-white/[0.01] transition-colors">
                            <td className="p-4 font-bold text-white">{app.jobTitle}</td>
                            <td className="p-4 text-slate-300">{app.companyName}</td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <div className="w-16 bg-slate-950/80 h-2 rounded-full overflow-hidden border border-white/5">
                                  <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full" style={{ width: `${app.score}%` }}></div>
                                </div>
                                <span className="font-mono font-bold text-slate-200">{app.score}%</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
                                app.analysis?.prediction === "Selected" ? "bg-emerald-950/50 text-emerald-400 border border-emerald-900" : "bg-slate-950 text-slate-500 border border-white/10"
                              }`}>
                                {app.analysis?.prediction || "Applied"}
                              </span>
                            </td>
                            <td className="p-4">
                              <span className={`font-mono uppercase font-bold text-[10px] ${
                                app.status === "Shortlisted" ? "text-emerald-400" : app.status === "Rejected" ? "text-red-400" : "text-slate-400"
                              }`}>
                                {app.status}
                              </span>
                            </td>
                            <td className="p-4">
                              <button 
                                onClick={() => setSelectedApp(app)}
                                className="px-3 py-1.5 bg-slate-950/50 hover:bg-white/[0.06] border border-white/10 rounded-lg text-indigo-400 hover:text-white transition-colors"
                              >
                                View Report
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: UPLOAD RESUME */}
        {activeTab === "upload" && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-black text-white">AI Resume Upload</h2>
              <p className="text-slate-400 text-xs">Submit resumes to execute automated parsing and screening.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Drag n drop box */}
              <div 
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`p-10 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center text-center transition-all min-h-[300px] ${
                  dragActive 
                    ? "bg-indigo-500/5 border-indigo-400 text-indigo-300" 
                    : "bg-white/[0.01] border-white/10 hover:border-white/20"
                }`}
              >
                <UploadCloud className={`w-16 h-16 text-slate-500 mb-4 ${uploadLoading && "animate-bounce"}`} />
                <h3 className="text-white font-bold text-base mb-1">Drag and drop your file</h3>
                <p className="text-slate-500 text-xs mb-6">Supports PDF, DOCX, or TXT (Max 50MB)</p>
                
                <input 
                  type="file" 
                  id="resume-file" 
                  accept=".pdf,.docx,.txt"
                  className="hidden" 
                  onChange={handleFileChange}
                />
                <label 
                  htmlFor="resume-file"
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-xl font-bold text-xs text-white shadow-md shadow-indigo-500/15 cursor-pointer hover:scale-[1.01] transition-transform"
                >
                  Select File From Device
                </label>
              </div>

              {/* Paste fallback */}
              <div className="bg-white/[0.02] border border-white/10 rounded-3xl p-6 sm:p-8">
                <h4 className="text-white font-bold text-sm mb-4">Paste Resume Plaintext Fallback</h4>
                <form onSubmit={handlePasteSubmit} className="space-y-4">
                  <textarea
                    rows={8}
                    required
                    value={pasteText}
                    onChange={(e) => setPasteText(e.target.value)}
                    className="w-full bg-slate-950/40 border border-white/10 rounded-2xl p-4 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono leading-relaxed"
                    placeholder="Enter Candidate Name, Email, Phone, Highest Education, Tech Skills, Experience details..."
                  ></textarea>
                  <button
                    type="submit"
                    disabled={uploadLoading || !pasteText.trim()}
                    className="w-full py-3 bg-slate-950 hover:bg-white/[0.06] border border-white/10 text-indigo-400 hover:text-white font-bold text-xs rounded-xl transition-all"
                  >
                    Parse Plaintext Resume
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: EDIT PROFILE */}
        {activeTab === "profile" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black text-white">Edit Candidate Profile</h2>
              <p className="text-slate-400 text-xs">Verify variables populated by AI parse and configure parameters manually.</p>
            </div>

            <form onSubmit={handleSaveProfile} className="bg-white/[0.02] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Full Name</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-slate-950/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full bg-slate-950/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Highest Education Academic Degree</label>
                  <input
                    type="text"
                    required
                    value={editEducation}
                    onChange={(e) => setEditEducation(e.target.value)}
                    className="w-full bg-slate-950/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. Master of Science in Computer Science"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Years of Working Experience</label>
                  <input
                    type="number"
                    required
                    value={editExperience}
                    onChange={(e) => setEditExperience(Number(e.target.value))}
                    className="w-full bg-slate-950/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              {/* Tag builder 1: Skills */}
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Skills Inventory Tag Builder</label>
                <div className="flex gap-2 max-w-md mb-3">
                  <input
                    type="text"
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addSkill(); } }}
                    className="flex-1 bg-slate-950/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. PyTorch"
                  />
                  <button type="button" onClick={addSkill} className="px-4 py-2.5 bg-slate-950 border border-white/10 text-xs rounded-xl hover:bg-white/[0.06] text-indigo-400 font-bold">Add</button>
                </div>
                <div className="flex flex-wrap gap-1.5 p-3 bg-slate-950/40 border border-white/10 rounded-2xl min-h-[50px]">
                  {skills.length === 0 ? (
                    <span className="text-slate-500 text-xs italic p-1">No skills added yet. Type and press Add.</span>
                  ) : (
                    skills.map((s, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-indigo-500/10 text-indigo-300 rounded-lg border border-indigo-500/20 text-xs flex items-center gap-1 font-mono">
                        <span>{s}</span>
                        <button type="button" onClick={() => removeSkill(idx)} className="text-slate-500 hover:text-red-400 text-[10px]">×</button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Tag builder 2: Certifications */}
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Professional Certifications</label>
                <div className="flex gap-2 max-w-md mb-3">
                  <input
                    type="text"
                    value={certInput}
                    onChange={(e) => setCertInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addCert(); } }}
                    className="flex-1 bg-slate-950/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    placeholder="e.g. AWS Solutions Architect"
                  />
                  <button type="button" onClick={addCert} className="px-4 py-2.5 bg-slate-950 border border-white/10 text-xs rounded-xl hover:bg-white/[0.06] text-indigo-400 font-bold">Add</button>
                </div>
                <div className="flex flex-wrap gap-1.5 p-3 bg-slate-950/40 border border-white/10 rounded-2xl min-h-[50px]">
                  {certs.length === 0 ? (
                    <span className="text-slate-500 text-xs italic p-1">No certifications added.</span>
                  ) : (
                    certs.map((c, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-purple-500/10 text-purple-300 rounded-lg border border-purple-500/20 text-xs flex items-center gap-1 font-mono">
                        <span>{c}</span>
                        <button type="button" onClick={() => removeCert(idx)} className="text-slate-500 hover:text-red-400 text-[10px]">×</button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Projects Array list */}
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">Key Projects Portfolio</label>
                
                <div className="bg-slate-950/40 p-5 rounded-2xl border border-white/10 mb-4 space-y-4 max-w-lg">
                  <h4 className="text-xs font-bold text-indigo-400 font-mono">Add Project</h4>
                  <input 
                    type="text" 
                    value={newProjTitle}
                    onChange={(e) => setNewProjTitle(e.target.value)}
                    className="w-full bg-slate-900/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500" 
                    placeholder="Project Title"
                  />
                  <textarea 
                    rows={2}
                    value={newProjDesc}
                    onChange={(e) => setNewProjDesc(e.target.value)}
                    className="w-full bg-slate-900/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500" 
                    placeholder="Short description"
                  ></textarea>
                  <input 
                    type="text" 
                    value={newProjTech}
                    onChange={(e) => setNewProjTech(e.target.value)}
                    className="w-full bg-slate-900/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500" 
                    placeholder="Technologies (comma separated, e.g. React, Node.js)"
                  />
                  <button type="button" onClick={addProject} className="w-full py-2.5 bg-slate-950 hover:bg-white/[0.04] border border-white/10 rounded-xl text-xs font-bold text-indigo-400 transition-colors">Add Project to Profile</button>
                </div>

                <div className="space-y-3">
                  {projects.length === 0 ? (
                    <p className="text-slate-500 text-xs italic">No projects listed in portfolio.</p>
                  ) : (
                    projects.map((proj, idx) => (
                      <div key={idx} className="p-4 bg-slate-950/20 border border-white/10 rounded-xl flex justify-between items-start">
                        <div>
                          <h5 className="text-xs font-bold text-white">{proj.title}</h5>
                          <p className="text-slate-400 text-[11px] mt-1">{proj.description}</p>
                          <div className="flex gap-1.5 mt-2">
                            {proj.technologies.map((t, tIdx) => (
                              <span key={tIdx} className="px-1.5 py-0.5 bg-slate-950 text-[10px] font-mono rounded text-slate-500 border border-white/10">{t}</span>
                            ))}
                          </div>
                        </div>
                        <button type="button" onClick={() => removeProject(idx)} className="p-1 text-slate-600 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs shadow-md shadow-indigo-500/20 transition-all cursor-pointer"
              >
                Save Profile Parameters
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
