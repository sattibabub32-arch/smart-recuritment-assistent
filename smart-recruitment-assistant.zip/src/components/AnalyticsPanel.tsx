import React from "react";
import { 
  ResponsiveContainer, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend 
} from "recharts";
import { AnalyticsMetrics } from "../types";
import { Award, Briefcase, FileText, CheckCircle, TrendingUp } from "lucide-react";

interface AnalyticsPanelProps {
  metrics: AnalyticsMetrics;
}

const COLORS = ["#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981", "#3b82f6"];

export default function AnalyticsPanel({ metrics }: AnalyticsPanelProps) {
  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. Numerical Metric Widgets */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Metric 1 */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">Total Talents</span>
            <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-400"><FileText className="w-4 h-4" /></div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">{metrics.totalCandidates}</p>
          <span className="text-[10px] text-emerald-400 font-mono font-semibold block mt-1">▲ Candidates Logged</span>
        </div>

        {/* Metric 2 */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">Active Jobs</span>
            <div className="p-2 bg-purple-500/10 rounded-xl text-purple-400"><Briefcase className="w-4 h-4" /></div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">{metrics.totalJobs}</p>
          <span className="text-[10px] text-emerald-400 font-mono font-semibold block mt-1">▲ Open Openings</span>
        </div>

        {/* Metric 3 */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">Applications</span>
            <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-400"><TrendingUp className="w-4 h-4" /></div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">{metrics.totalApplications}</p>
          <span className="text-[10px] text-emerald-400 font-mono font-semibold block mt-1">▲ Submitted Resumes</span>
        </div>

        {/* Metric 4 */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">Shortlisted</span>
            <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-400"><CheckCircle className="w-4 h-4" /></div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">{metrics.shortlistedCandidates}</p>
          <span className="text-[10px] text-emerald-400 font-mono font-semibold block mt-1">▲ Ready for Interview</span>
        </div>

        {/* Metric 5 */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-md col-span-2 lg:col-span-1">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wide">Average Match</span>
            <div className="p-2 bg-amber-500/10 rounded-xl text-amber-400"><Award className="w-4 h-4" /></div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">{metrics.averageScore}%</p>
          <span className="text-[10px] text-amber-400 font-mono font-semibold block mt-1">System Matching Mean</span>
        </div>
      </div>

      {/* 2. Visual Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Chart 1: Recruitment Funnel */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
          <h3 className="text-sm font-bold text-white mb-6 font-mono uppercase tracking-wider text-slate-300">Recruitment Screening Funnel</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={metrics.recruitmentFunnel} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="stage" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0e121a", borderColor: "rgba(255,255,255,0.1)" }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold" }}
                  itemStyle={{ color: "#6366f1" }}
                />
                <Bar dataKey="count" fill="url(#funnelGradient)" radius={[4, 4, 0, 0]}>
                  {/* Custom Gradients */}
                  <defs>
                    <linearGradient id="funnelGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#a855f7" />
                    </linearGradient>
                  </defs>
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Monthly Applications Line/Area */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
          <h3 className="text-sm font-bold text-white mb-6 font-mono uppercase tracking-wider text-slate-300">Application Velocity Trend</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={metrics.monthlyApplications} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                <defs>
                  <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0e121a", borderColor: "rgba(255,255,255,0.1)" }}
                  itemStyle={{ color: "#a855f7" }}
                />
                <Area type="monotone" dataKey="apps" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#areaGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Candidate Skill Categories distribution */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 lg:col-span-2">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider text-slate-300">Candidate Technical Core Competencies</h3>
            <span className="text-xs text-slate-500 font-mono">Aggregated Skill Taxonomy Distribution</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 items-center gap-8">
            <div className="h-64 md:col-span-2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={metrics.skillDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={85}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {metrics.skillDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0e121a", borderColor: "rgba(255,255,255,0.1)" }}
                    itemStyle={{ color: "#cbd5e1" }}
                  />
                  <Legend verticalAlign="bottom" height={36} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* List breakdown legend details */}
            <div className="space-y-3 bg-black/40 p-5 rounded-xl border border-white/10 font-mono">
              <h4 className="text-xs font-bold text-indigo-400">Taxonomy Breakdown</h4>
              {metrics.skillDistribution.map((entry, index) => (
                <div key={index} className="flex justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                    <span className="text-slate-400">{entry.name}</span>
                  </div>
                  <span className="text-slate-200 font-bold">{entry.value} keywords</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
