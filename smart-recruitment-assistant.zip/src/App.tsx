import React, { useState, useEffect } from "react";
import Home from "./components/Home";
import Auth from "./components/Auth";
import CandidateDashboard from "./components/CandidateDashboard";
import RecruiterDashboard from "./components/RecruiterDashboard";
import AdminDashboard from "./components/AdminDashboard";

export default function App() {
  const [view, setView] = useState<string>("home");
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<any | null>(null);

  useEffect(() => {
    // Read existing sessions on startup
    const storedToken = localStorage.getItem("srt_token");
    const storedUser = localStorage.getItem("srt_user");

    if (storedToken && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setToken(storedToken);
        setUser(parsedUser);
        
        // Dynamic dashboard routing on session restore
        if (parsedUser.role === "Candidate") {
          setView("candidate-dashboard");
        } else if (parsedUser.role === "Recruiter") {
          setView("recruiter-dashboard");
        } else if (parsedUser.role === "Admin") {
          setView("admin-dashboard");
        }
      } catch (e) {
        // Clear corrupt state keys
        localStorage.removeItem("srt_token");
        localStorage.removeItem("srt_user");
      }
    }
  }, []);

  const handleAuthSuccess = (authToken: string, authUser: any) => {
    localStorage.setItem("srt_token", authToken);
    localStorage.setItem("srt_user", JSON.stringify(authUser));
    setToken(authToken);
    setUser(authUser);

    // Route based on role
    if (authUser.role === "Candidate") {
      setView("candidate-dashboard");
    } else if (authUser.role === "Recruiter") {
      setView("recruiter-dashboard");
    } else if (authUser.role === "Admin") {
      setView("admin-dashboard");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("srt_token");
    localStorage.removeItem("srt_user");
    setToken(null);
    setUser(null);
    setView("home");
  };

  return (
    <div className="bg-[#0b0e14] min-h-screen text-slate-200 selection:bg-indigo-500 selection:text-white">
      {view === "home" && (
        <Home 
          onNavigate={setView} 
          isAuthenticated={!!token} 
          userRole={user?.role} 
          onLogout={handleLogout} 
        />
      )}

      {(view === "login" || view === "register") && (
        <Auth 
          onAuthSuccess={handleAuthSuccess} 
          onNavigate={setView} 
          initialMode={view === "login" ? "login" : "register"} 
        />
      )}

      {view === "candidate-dashboard" && token && user && (
        <CandidateDashboard 
          token={token} 
          user={user} 
          onLogout={handleLogout} 
          onNavigate={setView} 
        />
      )}

      {view === "recruiter-dashboard" && token && user && (
        <RecruiterDashboard 
          token={token} 
          user={user} 
          onLogout={handleLogout} 
          onNavigate={setView} 
        />
      )}

      {view === "admin-dashboard" && token && user && (
        <AdminDashboard 
          token={token} 
          user={user} 
          onLogout={handleLogout} 
          onNavigate={setView} 
        />
      )}
    </div>
  );
}
