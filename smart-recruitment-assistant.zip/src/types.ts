export interface User {
  _id: string;
  name: string;
  email: string;
  role: "Candidate" | "Recruiter" | "Admin";
  verified?: boolean;
}

export interface CandidateDetails {
  userId: string;
  education: string;
  experience: number;
  skills: string[];
  resumeText: string;
  matchScore: number;
  certifications?: string[];
  languages?: string[];
  projects?: Array<{
    title: string;
    description: string;
    technologies: string[];
  }>;
  profilePhoto?: string;
}

export interface RecruiterDetails {
  userId: string;
  company: string;
  designation: string;
}

export interface Job {
  _id: string;
  title: string;
  description: string;
  requiredSkills: string[];
  experience: number;
  salary: string;
  location: string;
  postedBy: string;
  createdAt: string;
  recruiterName?: string;
  companyName?: string;
}

export interface Application {
  _id: string;
  candidateId: string;
  jobId: string;
  resumeText: string;
  score: number;
  status: "Applied" | "Shortlisted" | "Rejected";
  createdAt: string;
  jobTitle?: string;
  companyName?: string;
  candidateName?: string;
  candidateEmail?: string;
  candidateSkills?: string[];
  candidateExperience?: number;
  analysis?: {
    skillsMatch: string[];
    skillsMissing: string[];
    experienceEvaluation: string;
    educationEvaluation: string;
    recommendation: string;
    prediction?: "Selected" | "Rejected";
  };
}

export interface AnalyticsMetrics {
  totalCandidates: number;
  totalJobs: number;
  totalApplications: number;
  shortlistedCandidates: number;
  averageScore: number;
  skillDistribution: Array<{ name: string; value: number }>;
  monthlyApplications: Array<{ month: string; apps: number }>;
  recruitmentFunnel: Array<{ stage: string; count: number }>;
}
