import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import apiRouter from "./server/server_api";
import { generateDatasets } from "./server/dataset";
import { mlEngine } from "./server/machine_learning";

async function startServer() {
  const app = express();
  const PORT = 3000;

  console.log("Initializing Smart Recruitment Assistant Full-Stack Bootloader...");

  // 1. Generate local skills and jobs CSV datasets (5000 skills / 1000 jobs)
  try {
    generateDatasets();
  } catch (e) {
    console.warn("Dataset generation skipped or failed:", e);
  }

  // 2. Train/warm-up Machine Learning model
  try {
    mlEngine.trainOnSyntheticData();
  } catch (e) {
    console.warn("ML model training skipped or failed:", e);
  }

  // 3. Configure Express body parsing (large limits for PDF base64 payloads)
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // 4. Mount API Routes
  app.use("/api", apiRouter);

  // Healthcheck Endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // 5. Integrate Vite Developer Middleware / Production SPA serving
  if (process.env.NODE_ENV !== "production") {
    console.log("Vite HMR running in Developer Sandbox Middleware Mode.");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static production build from /dist directory.");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // 6. Start listening on Port 3000
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server successfully active on: http://0.0.0.0:${PORT}`);
  });
}

startServer();
