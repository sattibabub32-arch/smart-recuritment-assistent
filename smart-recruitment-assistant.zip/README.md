# Smart Recruitment Assistant
### Premium Full-Stack AI & Machine Learning Screening Platform

An industry-grade, enterprise-scale automated recruiting platform that orchestrates **Gemini AI parsing**, **Cosine Similarity NLP vector matching**, and custom **Logistic Regression** machine learning pipelines to parse, match, score, and rank candidates instantly.

---

## 1. ARCHITECTURE BLUEPRINT

The application follows a robust **Full-Stack decouple-capable Architecture** utilizing **Vite/React** for the user interface, **Express/Node.js** for the backend API, and a secure thread-safe **simulated MongoDB file engine** for persistent storage.

```
       +-----------------------------------------------------------+
       |                     REACT.JS FRONTEND                     |
       +-----------------------------------------------------------+
         /           |                      |                    \
        /            |                      |                     \
   [Landing Page] [Auth Module]  [Candidate Dashboard]  [Recruiter Panel]
        \            |                      |                     /
         \           v                      v                    /
       +-----------------------------------------------------------+
       |                     REST API GATEWAY                      |
       |                   (Express Middleware)                    |
       +-----------------------------------------------------------+
                             |
         +-------------------+-------------------+
         |                   |                   |
         v                   v                   v
   +-----------+       +-----------+       +-----------+
   |   JWT &   |       |  Gemini   |       | NLP & ML  |
   | Password  |       |  Parsing  |       | Engine    |
   | Security  |       | Engine    |       | Classify  |
   +-----------+       +-----------+       +-----------+
         |                   |                   |
         |                   |                   |
         +-------------------+-------------------+
                             |
                             v
               +---------------------------+
               |  JSON MongoDB SIMULATION  |
               |     Persistence Layer     |
               +---------------------------+
```

---

## 2. DATABASE ENTITY RELATIONSHIP MODEL (ERD)

The persistent storage layer simulates highly normalized collections with absolute validation parameters.

### Users Collection
Stores base credentials and role identifiers.
- `_id`: string (UUID)
- `name`: string
- `email`: string (Unique Index)
- `password`: string (Bcrypt hashed)
- `role`: string ("Candidate" | "Recruiter" | "Admin")

### Candidates Collection
Holds candidate taxonomy and extracted profile variables.
- `userId`: string (FK -> Users)
- `education`: string
- `experience`: number (Years)
- `skills`: Array<string>
- `certifications`: Array<string>
- `languages`: Array<string>
- `projects`: Array<{ title, description, technologies }>
- `resumeText`: string (Raw extracted plain text)

### Recruiters Collection
Represents organizational profile fields.
- `userId`: string (FK -> Users)
- `company`: string
- `designation`: string

### Jobs Collection
Job openings posted by organizations.
- `_id`: string (UUID)
- `title`: string
- `description`: string
- `requiredSkills`: Array<string>
- `experience`: number (Min Target Years)
- `salary`: string
- `location`: string ("Remote" | "Hybrid" | "Onsite")
- `postedBy`: string (FK -> Users Recruiter)

### Applications Collection
Integrates candidates and job requirements with neural analysis values.
- `_id`: string (UUID)
- `candidateId`: string (FK -> Users Candidate)
- `jobId`: string (FK -> Jobs)
- `resumeText`: string (Copy of document contents)
- `score`: number (TF-IDF Cosine Similarity, 0-100)
- `status`: string ("Applied" | "Shortlisted" | "Rejected")
- `createdAt`: string (ISO)
- `analysis`: {
    skillsMatch: Array<string>,
    skillsMissing: Array<string>,
    experienceEvaluation: string,
    educationEvaluation: string,
    recommendation: string,
    prediction: "Selected" | "Rejected"
  }

---

## 3. CORE NLP & MACHINE LEARNING PIPELINE

### A. Skill Matching Matrix (Cosine TF-IDF)
1. **Tokenization**: Standardizes skills arrays into clean, lower-cased keyword strings.
2. **Term Frequency Representation**: Vectors are calculated representing term frequency densities.
3. **Cosine Similarity**: Computes the exact dot product similarity coefficient between Candidate skills and Recruiter requirements:
   $$\text{Similarity}(A, B) = \frac{A \cdot B}{\|A\| \|B\|}$$

### B. Machine Learning Classification (Logistic Regression)
Estimates candidate shortlist probabilities using a custom-developed Gradient Descent Logistic Regression Model:
$$\hat{y} = \sigma(w^T x + b) = \frac{1}{1 + e^{-(w^T x + b)}}$$

Features extracted for classification:
- **Feature 0**: Cosine Skills Match Ratio (0.0 to 1.0)
- **Feature 1**: Experience Suitability Delta ($\max(0, \text{Candidate Exp} - \text{Job Exp})$)

---

## 4. SYSTEM USE CASE FLOW

```
[Candidate] ----------> (Upload & AI Parse Resume) ----------> [Gemini Parser]
    |                                                                |
    v                                                                v
(Instant Apply) ------> [Compute Cosine TF-IDF Match] ---------> [Matcher Engine]
    |                                                                |
    v                                                                v
(ML Predict) ---------> [Logistic Classifier Predict] ---------> [ML Engine]
    |                                                                |
    +-----------------> [Display Rankings Matrix] -------------> [Recruiter]
```

---

## 5. COMPLETE API ROUTE DOCUMENTATION

All endpoints are mounted on prefix `/api`.

### Authentication Desk
- `POST /api/register`: Creates new Candidate or Recruiter profiles.
- `POST /api/login`: Validates password credentials and returns a secure JWT.
- `POST /api/forgot-password`: Simulates recovery verification links.
- `POST /api/reset-password`: Resets workspace credentials.

### Jobs Desk
- `GET /api/jobs`: Retrieves listed job openings.
- `POST /api/jobs` *(Bearer)*: Creates new job listings.
- `PUT /api/jobs` *(Bearer)*: Modifies job listings.
- `DELETE /api/jobs?id=XXX` *(Bearer)*: Removes job listings and purges associated applications.

### Candidate Desk
- `GET /api/profile` *(Bearer)*: Retrieves active candidate details.
- `PUT /api/profile` *(Bearer)*: Updates skills, experience, and educational parameters.
- `POST /api/upload_resume` *(Bearer)*: Executes Gemini-powered resume document parser.

### Applications Desk
- `POST /api/apply` *(Bearer)*: Calculates match scores, executes ML class predictions, and submits application.
- `GET /api/applications` *(Bearer)*: Lists submitted applications with complete AI reports.
- `PUT /api/applications` *(Bearer)*: Allows recruiters to Shortlist or Reject candidates.

### Administrative Desk
- `GET /api/admin/users` *(Bearer Admin)*: Lists all registered accounts.
- `DELETE /api/admin/users?id=XXX` *(Bearer Admin)*: Prunes spam profiles.

---

## 6. END-USER PLATFORM MANUAL

### Step 1: Portal Onboarding
1. Click **Get Started** or **Sign In** on the Hero landing page.
2. Select **Candidate** role, input name/email, and declare a secure password to create an account.

### Step 2: AI Parsing Upload
1. Navigate to the **Upload Resume** sidebar.
2. Drag and drop any resume document (PDF, DOCX, TXT) or paste raw resume text.
3. Click **Parse Plaintext**. The Gemini AI model extracts your skills list, experience years, and highest education automatically!

### Step 3: Smart Job Application
1. Navigate to **Search Jobs** on the Candidate Dashboard.
2. Browse through posted positions, filter by location or experience requirements.
3. Click **Apply Instantly**. The neural engine matches your skills, runs the Logistic Classifier, and outputs your match scorecard immediately under **My Applications**.

### Step 4: Recruiter Dashboard & Rankings
1. Register a separate **Recruiter** profile (declare designation and organization company name).
2. Create job postings detailing target experience years and a comma-separated list of core skills.
3. Select any posting on the **Rank Candidates** tab. Applicants are listed in descending order sorted by their exact matching percentages, including complete summaries of matched and missing skills.
4. Click **Download/View** to inspect the clean resume file or click **Shortlist** to schedule interviews!
