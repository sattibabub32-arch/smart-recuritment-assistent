import fs from "fs";
import path from "path";

const MODEL_FILE = path.join(process.cwd(), "trained_models", "logistic_regression_model.json");

interface ModelWeights {
  weights: number[];
  bias: number;
}

export class LogisticRegression {
  private weights: number[] = [];
  private bias: number = 0;
  private learningRate: number = 0.1;
  private iterations: number = 1000;

  constructor() {
    this.loadModel();
  }

  private sigmoid(z: number): number {
    return 1 / (1 + Math.exp(-z));
  }

  // Train model using Gradient Descent
  public train(X: number[][], y: number[]): void {
    const numSamples = X.length;
    if (numSamples === 0) return;
    const numFeatures = X[0].length;

    // Initialize weights and bias
    this.weights = new Array(numFeatures).fill(0);
    this.bias = 0;

    for (let iter = 0; iter < this.iterations; iter++) {
      let dw = new Array(numFeatures).fill(0);
      let db = 0;

      for (let i = 0; i < numSamples; i++) {
        const z = X[i].reduce((sum, val, idx) => sum + val * this.weights[idx], 0) + this.bias;
        const prediction = this.sigmoid(z);
        const error = prediction - y[i];

        for (let j = 0; j < numFeatures; j++) {
          dw[j] += error * X[i][j];
        }
        db += error;
      }

      for (let j = 0; j < numFeatures; j++) {
        this.weights[j] -= (this.learningRate * dw[j]) / numSamples;
      }
      this.bias -= (this.learningRate * db) / numSamples;
    }

    this.saveModel();
  }

  // Predict probability of Selection (1.0 = Selected, 0.0 = Rejected)
  public predictProbability(features: number[]): number {
    if (this.weights.length === 0) {
      // Default fallback weights if not trained
      // [SkillMatchWeight, ExperienceMatchWeight, ResumeQualityWeight, HighDemandSkillWeight]
      this.weights = [3.5, 1.5, 1.0, 0.8];
      this.bias = -2.5;
    }
    const z = features.reduce((sum, val, idx) => sum + val * (this.weights[idx] || 0), 0) + this.bias;
    return this.sigmoid(z);
  }

  // Predict discrete outcome: Selected or Rejected
  public predict(features: number[]): { outcome: "Selected" | "Rejected"; confidence: number } {
    const prob = this.predictProbability(features);
    return {
      outcome: prob >= 0.55 ? "Selected" : "Rejected",
      confidence: Math.round(prob >= 0.55 ? prob * 100 : (1 - prob) * 100),
    };
  }

  private saveModel(): void {
    const modelDir = path.dirname(MODEL_FILE);
    if (!fs.existsSync(modelDir)) {
      fs.mkdirSync(modelDir, { recursive: true });
    }
    const data: ModelWeights = {
      weights: this.weights,
      bias: this.bias,
    };
    fs.writeFileSync(MODEL_FILE, JSON.stringify(data, null, 2), "utf8");
    console.log(`ML model weights saved to: ${MODEL_FILE}`);
  }

  private loadModel(): void {
    try {
      if (fs.existsSync(MODEL_FILE)) {
        const content = fs.readFileSync(MODEL_FILE, "utf8");
        const data: ModelWeights = JSON.parse(content);
        this.weights = data.weights;
        this.bias = data.bias;
        console.log("ML model loaded successfully from storage.");
      } else {
        // Run initial training on synthetic data to persist weights
        this.trainOnSyntheticData();
      }
    } catch (e) {
      console.warn("Failed to load ML model, using defaults.", e);
    }
  }

  public trainOnSyntheticData(): void {
    console.log("Training ML model on synthetic historical recruitment data...");
    // Features: [SkillMatch (0-1), ExperienceGap (0-1, where 1 means meets or exceeds requirement), Completeness (0-1), DemandMultiplier (0-1)]
    const X: number[][] = [
      [0.9, 1.0, 0.9, 0.8], // Perfect candidate -> Selected
      [0.8, 0.8, 0.8, 0.7], // Strong candidate -> Selected
      [0.3, 0.2, 0.4, 0.3], // Weak candidate -> Rejected
      [0.1, 0.0, 0.2, 0.1], // Unqualified -> Rejected
      [0.7, 1.0, 0.6, 0.5], // Good experience, decent skills -> Selected
      [0.4, 0.9, 0.5, 0.3], // Good experience but very low skills match -> Rejected
      [0.9, 0.3, 0.8, 0.8], // High skills match but slightly lower experience -> Selected
      [0.5, 0.5, 0.9, 0.9], // Medium skill, complete resume -> Selected (marginal)
      [0.2, 0.8, 0.3, 0.2], // Low skills, incomplete resume -> Rejected
      [0.95, 0.9, 0.95, 0.9], // Elite candidate -> Selected
    ];
    // Outcomes: 1 = Selected, 0 = Rejected
    const y: number[] = [1, 1, 0, 0, 1, 0, 1, 1, 0, 1];

    this.train(X, y);
  }
}

export const mlEngine = new LogisticRegression();

// Extract numerical features from a candidate application for model consumption
export function extractFeaturesForML(
  skillsMatchRatio: number, // 0.0 to 1.0
  candidateExp: number,
  requiredExp: number,
  resumeTextLength: number,
  hasCertifications: boolean,
  hasProjects: boolean
): number[] {
  // 1. Skill Match (0.0 to 1.0)
  const f1 = skillsMatchRatio;

  // 2. Experience ratio (cap at 1.5, normalized)
  const expRatio = requiredExp === 0 ? 1.0 : candidateExp / requiredExp;
  const f2 = Math.min(expRatio, 1.5) / 1.5;

  // 3. Resume completeness / Quality
  let f3 = 0.4;
  if (resumeTextLength > 300) f3 += 0.2;
  if (hasCertifications) f3 += 0.2;
  if (hasProjects) f3 += 0.2;
  f3 = Math.min(f3, 1.0);

  // 4. Custom skill diversity / demand proxy
  const f4 = skillsMatchRatio > 0.6 ? 0.9 : skillsMatchRatio > 0.3 ? 0.5 : 0.2;

  return [f1, f2, f3, f4];
}
