import fs from "fs";
import path from "path";

const DB_FILE = path.join(process.cwd(), "data", "db.json");

// Define basic interface for documents
export interface BaseDocument {
  _id: string;
  createdAt: string;
  [key: string]: any;
}

export interface User extends BaseDocument {
  name: string;
  email: string;
  passwordHash: string;
  role: "Candidate" | "Recruiter" | "Admin";
  verified?: boolean; // For Recruiters verified by Admin
}

export interface Candidate extends BaseDocument {
  userId: string;
  education: string;
  experience: number; // Years of experience
  skills: string[];
  resumeText: string;
  matchScore: number;
  educationDetails?: any[];
  experienceDetails?: any[];
  projects?: any[];
  certifications?: string[];
  languages?: string[];
  profilePhoto?: string;
}

export interface Recruiter extends BaseDocument {
  userId: string;
  company: string;
  designation: string;
}

export interface Job extends BaseDocument {
  title: string;
  description: string;
  requiredSkills: string[];
  experience: number; // Required years of experience
  salary: string;
  location: string;
  postedBy: string; // User ID of Recruiter
  approved?: boolean; // Admin approval
}

export interface Application extends BaseDocument {
  candidateId: string; // Candidate User ID
  jobId: string;
  resumeText: string;
  score: number;
  status: "Applied" | "Shortlisted" | "Rejected";
  analysis?: {
    skillsMatch: string[];
    skillsMissing: string[];
    experienceEvaluation: string;
    educationEvaluation: string;
    recommendation: string;
    prediction?: "Selected" | "Rejected";
  };
}

export interface Analytics extends BaseDocument {
  totalCandidates: number;
  totalJobs: number;
  selectedCandidates: number;
  averageScore: number;
}

class Collection<T extends BaseDocument> {
  private name: string;
  private db: LocalDatabase;

  constructor(name: string, db: LocalDatabase) {
    this.name = name;
    this.db = db;
  }

  private getData(): T[] {
    const data = this.db.read();
    return (data[this.name] || []) as T[];
  }

  private saveData(items: T[]): void {
    const data = this.db.read();
    data[this.name] = items;
    this.db.write(data);
  }

  public find(filter: Partial<T> = {}): T[] {
    const items = this.getData();
    return items.filter((item) => {
      for (const key in filter) {
        if (filter[key] !== undefined && item[key] !== filter[key]) {
          return false;
        }
      }
      return true;
    });
  }

  public findOne(filter: Partial<T>): T | null {
    const items = this.find(filter);
    return items.length > 0 ? items[0] : null;
  }

  public insertOne(doc: Omit<T, "_id" | "createdAt">): T {
    const items = this.getData();
    const newId = Math.random().toString(36).substring(2, 11);
    const newDoc = {
      ...doc,
      _id: newId,
      createdAt: new Date().toISOString(),
    } as unknown as T;

    items.push(newDoc);
    this.saveData(items);
    return newDoc;
  }

  public updateOne(filter: Partial<T>, update: Partial<T>): boolean {
    const items = this.getData();
    const index = items.findIndex((item) => {
      for (const key in filter) {
        if (filter[key] !== undefined && item[key] !== filter[key]) {
          return false;
        }
      }
      return true;
    });

    if (index === -1) return false;

    items[index] = {
      ...items[index],
      ...update,
    };
    this.saveData(items);
    return true;
  }

  public deleteOne(filter: Partial<T>): boolean {
    const items = this.getData();
    const index = items.findIndex((item) => {
      for (const key in filter) {
        if (filter[key] !== undefined && item[key] !== filter[key]) {
          return false;
        }
      }
      return true;
    });

    if (index === -1) return false;

    items.splice(index, 1);
    this.saveData(items);
    return true;
  }

  public deleteMany(filter: Partial<T>): number {
    const items = this.getData();
    const initialCount = items.length;
    const remaining = items.filter((item) => {
      for (const key in filter) {
        if (filter[key] !== undefined && item[key] !== filter[key]) {
          return true;
        }
      }
      return false;
    });

    this.saveData(remaining);
    return initialCount - remaining.length;
  }
}

class LocalDatabase {
  private cache: Record<string, any> | null = null;

  constructor() {
    this.init();
  }

  private init() {
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify({}, null, 2), "utf8");
    }
  }

  public read(): Record<string, any> {
    if (this.cache) return this.cache;
    try {
      const content = fs.readFileSync(DB_FILE, "utf8");
      this.cache = JSON.parse(content);
      return this.cache || {};
    } catch (e) {
      return {};
    }
  }

  public write(data: Record<string, any>): void {
    this.cache = data;
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf8");
  }

  // Collections accessors
  public get users() {
    return new Collection<User>("users", this);
  }

  public get candidates() {
    return new Collection<Candidate>("candidates", this);
  }

  public get recruiters() {
    return new Collection<Recruiter>("recruiters", this);
  }

  public get jobs() {
    return new Collection<Job>("jobs", this);
  }

  public get applications() {
    return new Collection<Application>("applications", this);
  }

  public get analytics() {
    return new Collection<Analytics>("analytics", this);
  }
}

export const db = new LocalDatabase();
