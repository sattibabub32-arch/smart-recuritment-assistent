import fs from "fs";
import path from "path";

const DATASET_DIR = path.join(process.cwd(), "dataset");

const JOB_TITLES = [
  "Software Engineer",
  "Python Developer",
  "ML Engineer",
  "AI Engineer",
  "Frontend Developer",
  "Backend Developer",
  "Full Stack Developer",
  "Data Analyst",
  "Data Scientist",
  "Cloud Engineer",
];

const SKILL_CATEGORIES = {
  Programming: ["Python", "JavaScript", "TypeScript", "Go", "Rust", "Java", "C++", "Ruby", "Swift", "PHP", "Scala", "C#", "Kotlin"],
  Frontend: ["React", "Angular", "Vue", "Next.js", "HTML5", "CSS3", "Tailwind CSS", "Bootstrap", "Webpack", "Vite", "Svelte", "Redux"],
  Backend: ["Node.js", "Express", "Flask", "Django", "FastAPI", "Spring Boot", "Ruby on Rails", "Laravel", "NestJS", "GraphQL"],
  Database: ["MongoDB", "PostgreSQL", "MySQL", "Redis", "SQLite", "DynamoDB", "Cassandra", "Elasticsearch", "Oracle", "Neo4j"],
  "AI/ML": ["PyTorch", "TensorFlow", "Scikit-learn", "Keras", "Pandas", "NumPy", "NLP", "Computer Vision", "NLTK", "spaCy", "Transformers", "LLMs"],
  Cloud_DevOps: ["AWS", "Azure", "GCP", "Docker", "Kubernetes", "CI/CD", "Terraform", "GitHub Actions", "Jenkins", "Linux", "Nginx", "Serverless"],
  Soft_Skills: ["Communication", "Problem Solving", "Teamwork", "Leadership", "Agile", "Scrum", "Critical Thinking", "Project Management"],
};

export function generateDatasets() {
  if (!fs.existsSync(DATASET_DIR)) {
    fs.mkdirSync(DATASET_DIR, { recursive: true });
  }

  const skillsCsvPath = path.join(DATASET_DIR, "skills_dataset.csv");
  const jobsCsvPath = path.join(DATASET_DIR, "jobs_dataset.csv");

  // 1. Generate skills_dataset.csv (5000 records)
  if (!fs.existsSync(skillsCsvPath)) {
    console.log("Generating skills_dataset.csv (5000 records)...");
    const skillHeaders = "id,skill_name,category,demand_level\n";
    let skillsContent = skillHeaders;

    const allCategories = Object.keys(SKILL_CATEGORIES);
    const demandLevels = ["High", "Medium", "Low"];

    let count = 0;
    while (count < 5000) {
      const category = allCategories[count % allCategories.length];
      const baseSkills = SKILL_CATEGORIES[category as keyof typeof SKILL_CATEGORIES];
      const baseSkill = baseSkills[count % baseSkills.length];
      
      // Generate synthetic variations or specific subsets to reach 5000 unique-ish items
      const skillName = count < 200 ? baseSkill : `${baseSkill} v${(count % 10) + 1}.0` || `${baseSkill} Spec ${count}`;
      const demand = demandLevels[count % demandLevels.length];

      skillsContent += `${count + 1},"${skillName.replace(/"/g, '""')}","${category}","${demand}"\n`;
      count++;
    }

    fs.writeFileSync(skillsCsvPath, skillsContent, "utf8");
    console.log(`Saved ${skillsCsvPath}`);
  }

  // 2. Generate jobs_dataset.csv (1000 records)
  if (!fs.existsSync(jobsCsvPath)) {
    console.log("Generating jobs_dataset.csv (1000 records)...");
    const jobHeaders = "id,title,category,description,required_skills,experience_required\n";
    let jobsContent = jobHeaders;

    const templates = [
      {
        title: "Software Engineer",
        category: "Software Development",
        desc: "Responsible for developing high-quality software applications, writing clean code, collaborating with cross-functional teams, and debugging systems.",
        skills: ["Java", "C++", "Git", "Problem Solving", "Agile"],
      },
      {
        title: "Python Developer",
        category: "Backend Development",
        desc: "Design and implement scalable Python backend applications, create API endpoints using Flask/Django, and manage SQL/NoSQL databases.",
        skills: ["Python", "Flask", "Django", "PostgreSQL", "REST APIs"],
      },
      {
        title: "ML Engineer",
        category: "AI & Data Science",
        desc: "Build, deploy, and maintain machine learning pipelines and models. Clean and structure complex datasets for optimal prediction accuracy.",
        skills: ["Python", "PyTorch", "TensorFlow", "Scikit-learn", "Pandas", "NumPy"],
      },
      {
        title: "AI Engineer",
        category: "AI & Data Science",
        desc: "Develop and integrate cutting-edge Generative AI models and LLMs. Apply natural language processing to extract insights and automate tasks.",
        skills: ["Python", "Transformers", "NLP", "LLMs", "Vector Databases", "Prompt Engineering"],
      },
      {
        title: "Frontend Developer",
        category: "Frontend Development",
        desc: "Create responsive, pixel-perfect user interfaces using modern React and Tailwind CSS. Optimize web performance and ensure accessibility.",
        skills: ["JavaScript", "TypeScript", "React", "HTML5", "CSS3", "Tailwind CSS"],
      },
      {
        title: "Backend Developer",
        category: "Backend Development",
        desc: "Build highly reliable server-side systems, manage database schemas, handle secure authentication protocols, and design RESTful APIs.",
        skills: ["Node.js", "Express", "MongoDB", "Redis", "Docker", "REST APIs"],
      },
      {
        title: "Full Stack Developer",
        category: "Full Stack Development",
        desc: "Manage end-to-end web architectures, working seamlessly with React frontend layouts and Node.js/Python server-side backends.",
        skills: ["React", "Node.js", "Express", "MongoDB", "Docker", "AWS", "TypeScript"],
      },
      {
        title: "Data Analyst",
        category: "AI & Data Science",
        desc: "Analyze business metrics, build dynamic reports and dashboards, clean high-volume tables, and present visual business insights.",
        skills: ["SQL", "Excel", "Tableau", "PowerBI", "Pandas", "Communication"],
      },
      {
        title: "Data Scientist",
        category: "AI & Data Science",
        desc: "Develop predictive systems and statistical analysis engines. Clean, transform, and leverage massive big-data inputs to solve complex problems.",
        skills: ["Python", "R", "SQL", "Scikit-learn", "Pandas", "Machine Learning", "Statistics"],
      },
      {
        title: "Cloud Engineer",
        category: "Cloud & DevOps",
        desc: "Provision cloud infrastructure on AWS, design automated CI/CD deployment pipelines, and scale dockerized microservice applications.",
        skills: ["AWS", "Docker", "Kubernetes", "CI/CD", "Terraform", "Linux"],
      },
    ];

    for (let i = 0; i < 1000; i++) {
      const template = templates[i % templates.length];
      const title = `${template.title} ${i % 3 === 0 ? "Senior" : i % 3 === 1 ? "Junior" : "Lead"}`;
      const expReq = (i % 8) + 1; // 1 to 8 years
      const skillsStr = template.skills.join("; ");
      const desc = `Join our growing enterprise team as a ${title}. ${template.desc} Looking for highly motivated candidates with at least ${expReq} years of industry experience.`;
      
      // Escape commas and quotes for standard CSV formatting
      const escapedTitle = `"${title.replace(/"/g, '""')}"`;
      const escapedCat = `"${template.category.replace(/"/g, '""')}"`;
      const escapedDesc = `"${desc.replace(/"/g, '""')}"`;
      const escapedSkills = `"${skillsStr.replace(/"/g, '""')}"`;

      jobsContent += `${i + 1},${escapedTitle},${escapedCat},${escapedDesc},${escapedSkills},${expReq}\n`;
    }

    fs.writeFileSync(jobsCsvPath, jobsContent, "utf8");
    console.log(`Saved ${jobsCsvPath}`);
  }
}
