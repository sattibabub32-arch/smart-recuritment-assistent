import { Router, Response } from "express";
import { db, User, Candidate, Recruiter, Job, Application } from "./database";
import { hashPassword, comparePassword, signToken, authenticateToken, authorizeRoles, AuthenticatedRequest } from "./auth";
import { parseResumeDocument, evaluateApplicationWithGemini } from "./resume_parser";
import { calculateSkillsMatch, tokenize, getTermFrequency, cosineSimilarity } from "./matcher";
import { mlEngine, extractFeaturesForML } from "./machine_learning";

const router = Router();

// ==========================================
// 1. AUTHENTICATION ENDPOINTS
// ==========================================

// POST /api/register
router.post("/register", async (req: any, res: any) => {
  try {
    const { name, email, password, role, company, designation } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: "Missing required registration parameters." });
    }

    const existingUser = db.users.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ error: "Email is already registered." });
    }

    const passwordHash = await hashPassword(password);
    
    // Admin is verified by default, Candidate is verified, Recruiters can be verified by Admin
    const user = db.users.insertOne({
      name,
      email,
      passwordHash,
      role,
      verified: role === "Recruiter" ? false : true,
    });

    if (role === "Candidate") {
      db.candidates.insertOne({
        userId: user._id,
        education: "",
        experience: 0,
        skills: [],
        resumeText: "",
        matchScore: 0,
        certifications: [],
        languages: [],
        projects: [],
      });
    } else if (role === "Recruiter") {
      db.recruiters.insertOne({
        userId: user._id,
        company: company || "Self-Employed",
        designation: designation || "Hiring Manager",
      });
    }

    const token = signToken({ _id: user._id, name: user.name, email: user.email, role: user.role });
    return res.status(201).json({
      message: "Registration successful.",
      token,
      user: { _id: user._id, name: user.name, email: user.email, role: user.role, verified: user.verified },
    });
  } catch (e: any) {
    return res.status(500).json({ error: "Server Registration Error: " + e.message });
  }
});

// POST /api/login
router.post("/login", async (req: any, res: any) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }

    const user = db.users.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const isMatch = await comparePassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const token = signToken({ _id: user._id, name: user.name, email: user.email, role: user.role });
    return res.status(200).json({
      message: "Login successful.",
      token,
      user: { _id: user._id, name: user.name, email: user.email, role: user.role, verified: user.verified },
    });
  } catch (e: any) {
    return res.status(500).json({ error: "Server Login Error: " + e.message });
  }
});

// POST /api/forgot-password (mock/instant reset helper for testing simplicity)
router.post("/forgot-password", async (req: any, res: any) => {
  const { email } = req.body;
  const user = db.users.findOne({ email });
  if (!user) {
    return res.status(404).json({ error: "User with this email does not exist." });
  }
  return res.json({ message: "Password reset instructions sent. Please check your inbox or proceed to Reset Password." });
});

// POST /api/reset-password
router.post("/reset-password", async (req: any, res: any) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword) {
    return res.status(400).json({ error: "Email and new password are required." });
  }
  const user = db.users.findOne({ email });
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }
  const passwordHash = await hashPassword(newPassword);
  db.users.updateOne({ email }, { passwordHash });
  return res.json({ message: "Password reset successfully. You can now login with your new password." });
});

// ==========================================
// 2. PROFILE MANAGEMENT
// ==========================================

// GET /api/profile
router.get("/profile", authenticateToken, (req: AuthenticatedRequest, res: any) => {
  try {
    const userId = req.user?._id;
    const user = db.users.findOne({ _id: userId });
    if (!user) return res.status(404).json({ error: "User not found." });

    let profileDetails: any = {};
    if (user.role === "Candidate") {
      profileDetails = db.candidates.findOne({ userId }) || {};
    } else if (user.role === "Recruiter") {
      profileDetails = db.recruiters.findOne({ userId }) || {};
    }

    return res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      verified: user.verified,
      createdAt: user.createdAt,
      details: profileDetails,
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// PUT /api/profile
router.put("/profile", authenticateToken, async (req: AuthenticatedRequest, res: any) => {
  try {
    const userId = req.user?._id;
    const { name, email, details } = req.body;

    // Update user root
    const userUpdate: any = {};
    if (name) userUpdate.name = name;
    if (email) userUpdate.email = email;
    db.users.updateOne({ _id: userId }, userUpdate);

    // Update specific role profile
    const user = db.users.findOne({ _id: userId });
    if (user?.role === "Candidate" && details) {
      db.candidates.updateOne(
        { userId },
        {
          education: details.education,
          experience: Number(details.experience) || 0,
          skills: Array.isArray(details.skills) ? details.skills : [],
          certifications: Array.isArray(details.certifications) ? details.certifications : [],
          languages: Array.isArray(details.languages) ? details.languages : [],
          projects: Array.isArray(details.projects) ? details.projects : [],
          profilePhoto: details.profilePhoto,
        }
      );
    } else if (user?.role === "Recruiter" && details) {
      db.recruiters.updateOne(
        { userId },
        {
          company: details.company,
          designation: details.designation,
        }
      );
    }

    return res.json({ message: "Profile updated successfully." });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// ==========================================
// 3. JOB POSTINGS ENDPOINTS
// ==========================================

// GET /api/jobs
router.get("/jobs", (req: any, res: any) => {
  try {
    const jobs = db.jobs.find();
    // Return all jobs. If Candidate or Recruiter, we can enrich with Poster name.
    const enrichedJobs = jobs.map((job) => {
      const poster = db.users.findOne({ _id: job.postedBy });
      const recruiter = db.recruiters.findOne({ userId: job.postedBy });
      return {
        ...job,
        recruiterName: poster ? poster.name : "System Recruiter",
        companyName: recruiter ? recruiter.company : "Global Tech Inc.",
      };
    });
    return res.json(enrichedJobs);
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// POST /api/jobs
router.post(
  "/jobs",
  authenticateToken,
  authorizeRoles("Recruiter", "Admin"),
  (req: AuthenticatedRequest, res: any) => {
    try {
      const { title, description, requiredSkills, experience, salary, location } = req.body;
      const userId = req.user?._id;

      if (!title || !description || !requiredSkills || experience === undefined) {
        return res.status(400).json({ error: "Missing required job specification details." });
      }

      const skillsArray = Array.isArray(requiredSkills)
        ? requiredSkills
        : requiredSkills.split(",").map((s: string) => s.trim());

      const job = db.jobs.insertOne({
        title,
        description,
        requiredSkills: skillsArray,
        experience: Number(experience) || 0,
        salary: salary || "Competitive",
        location: location || "Remote",
        postedBy: userId!,
        approved: true, // Auto approved for prototype ease
      });

      return res.status(201).json({ message: "Job posted successfully.", job });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
);

// PUT /api/jobs
router.put(
  "/jobs",
  authenticateToken,
  authorizeRoles("Recruiter", "Admin"),
  (req: AuthenticatedRequest, res: any) => {
    try {
      const { _id, title, description, requiredSkills, experience, salary, location } = req.body;
      const job = db.jobs.findOne({ _id });

      if (!job) return res.status(404).json({ error: "Job listing not found." });

      // Security check: Only original poster or Admin can edit
      if (req.user?.role !== "Admin" && job.postedBy !== req.user?._id) {
        return res.status(403).json({ error: "Forbidden: You cannot modify this job posting." });
      }

      const skillsArray = Array.isArray(requiredSkills)
        ? requiredSkills
        : requiredSkills.split(",").map((s: string) => s.trim());

      db.jobs.updateOne(
        { _id },
        {
          title: title || job.title,
          description: description || job.description,
          requiredSkills: skillsArray,
          experience: experience !== undefined ? Number(experience) : job.experience,
          salary: salary || job.salary,
          location: location || job.location,
        }
      );

      return res.json({ message: "Job posting updated successfully." });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
);

// DELETE /api/jobs
router.delete(
  "/jobs",
  authenticateToken,
  authorizeRoles("Recruiter", "Admin"),
  (req: AuthenticatedRequest, res: any) => {
    try {
      const { id } = req.query;
      const jobId = id as string;
      const job = db.jobs.findOne({ _id: jobId });

      if (!job) return res.status(404).json({ error: "Job listing not found." });

      if (req.user?.role !== "Admin" && job.postedBy !== req.user?._id) {
        return res.status(403).json({ error: "Forbidden: You cannot delete this job posting." });
      }

      db.jobs.deleteOne({ _id: jobId });
      // Delete associated applications
      db.applications.deleteMany({ jobId });

      return res.json({ message: "Job posting deleted successfully." });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
);

// ==========================================
// 4. RESUME AI PARSING & SCORING
// ==========================================

// POST /api/upload_resume
router.post("/upload_resume", authenticateToken, async (req: AuthenticatedRequest, res: any) => {
  try {
    const { base64File, textContent, mimeType } = req.body;
    const userId = req.user?._id;

    if (!textContent && !base64File) {
      return res.status(400).json({ error: "Please upload a resume file or input resume text." });
    }

    let fileBuffer: Buffer | null = null;
    if (base64File) {
      fileBuffer = Buffer.from(base64File, "base64");
    }

    const parsed = await parseResumeDocument(fileBuffer, textContent || "", mimeType || "text/plain");

    // Update candidate profile with newly parsed details
    db.candidates.updateOne(
      { userId },
      {
        education: parsed.education,
        experience: parsed.experience,
        skills: parsed.skills,
        certifications: parsed.certifications,
        languages: parsed.languages,
        projects: parsed.projects,
        resumeText: textContent || `AI Parsed Resume for ${parsed.name}`,
      }
    );

    return res.json({
      message: "Resume uploaded and parsed successfully.",
      profile: parsed,
    });
  } catch (e: any) {
    return res.status(500).json({ error: "Resume Parsing Error: " + e.message });
  }
});

// POST /api/analyze_resume (interactive sandbox analysis)
router.post("/analyze_resume", authenticateToken, async (req: AuthenticatedRequest, res: any) => {
  try {
    const { resumeText, jobDescription } = req.body;
    if (!resumeText || !jobDescription) {
      return res.status(400).json({ error: "Resume text and Job description are required for analysis." });
    }

    // Standard local cosine similarity computation on raw words
    const tokensRes = tokenize(resumeText);
    const tokensJob = tokenize(jobDescription);
    const tfRes = getTermFrequency(tokensRes);
    const tfJob = getTermFrequency(tokensJob);
    const cosScore = cosineSimilarity(tfRes, tfJob);

    // Call Gemini to do a full comprehensive recruitment evaluation
    // We parse resume text locally to mock a parsed resume struct
    const parsedMock = await parseResumeDocument(null, resumeText, "text/plain");
    const aiAnalysis = await evaluateApplicationWithGemini(
      parsedMock,
      jobDescription,
      parsedMock.skills.slice(0, 5), // dynamic proxy
      2
    );

    return res.json({
      cosineSimilarityScore: Math.round(cosScore * 100),
      aiAnalysis,
      parsedCandidate: parsedMock,
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// ==========================================
// 5. APPLICATION SUBMISSION & ML PREDICTION
// ==========================================

// POST /api/apply
router.post("/apply", authenticateToken, authorizeRoles("Candidate"), async (req: AuthenticatedRequest, res: any) => {
  try {
    const { jobId } = req.body;
    const userId = req.user?._id;

    if (!jobId) return res.status(400).json({ error: "Job ID is required." });

    const job = db.jobs.findOne({ _id: jobId });
    if (!job) return res.status(404).json({ error: "Job posting not found." });

    const candidate = db.candidates.findOne({ userId });
    if (!candidate || !candidate.skills || candidate.skills.length === 0) {
      return res.status(400).json({ error: "Please upload and parse your resume before applying." });
    }

    // Check if already applied
    const existingApp = db.applications.findOne({ candidateId: userId, jobId });
    if (existingApp) {
      return res.status(409).json({ error: "You have already applied for this job listing." });
    }

    // 1. Calculate matching score (hybrid)
    const skillsAnalysis = calculateSkillsMatch(candidate.skills, job.requiredSkills);
    
    const expScore = candidate.experience >= job.experience ? 25 : Math.round((candidate.experience / job.experience) * 25);
    const edScore = candidate.education.toLowerCase().includes("master") || candidate.education.toLowerCase().includes("phd") ? 15 : 12;
    const qualityScore = Math.min((candidate.projects?.length || 0) * 3 + (candidate.certifications?.length || 0) * 3 + 4, 10);
    const skillScoreValue = Math.round(skillsAnalysis.score * 0.5); // Weighting: 50% skills, 25% experience, 15% education, 10% completeness

    const finalMatchScore = skillScoreValue + expScore + edScore + qualityScore;

    // 2. Machine Learning Prediction (Logistic Regression)
    const features = extractFeaturesForML(
      skillsAnalysis.score / 100,
      candidate.experience,
      job.experience,
      candidate.resumeText.length,
      (candidate.certifications?.length || 0) > 0,
      (candidate.projects?.length || 0) > 0
    );

    const mlPrediction = mlEngine.predict(features);

    // 3. Gemini Detailed AI Audit (skillsMatch, missing, suggestions)
    const aiAnalysis = await evaluateApplicationWithGemini(
      candidate as any,
      job.description,
      job.requiredSkills,
      job.experience
    );

    // Insert Application
    const application = db.applications.insertOne({
      candidateId: userId!,
      jobId,
      resumeText: candidate.resumeText,
      score: finalMatchScore,
      status: mlPrediction.outcome === "Selected" ? "Shortlisted" : "Applied", // Seed status based on ML suggestion
      analysis: {
        ...aiAnalysis,
        prediction: mlPrediction.outcome,
      },
    });

    return res.status(201).json({
      message: "Application submitted successfully.",
      application,
      score: finalMatchScore,
      mlPrediction,
    });
  } catch (e: any) {
    return res.status(500).json({ error: "Application Error: " + e.message });
  }
});

// ==========================================
// 6. CANDIDATE RANKINGS & APPLICANTS
// ==========================================

// GET /api/applications
router.get("/applications", authenticateToken, (req: AuthenticatedRequest, res: any) => {
  try {
    const userId = req.user?._id;
    const role = req.user?.role;

    let applications: Application[] = [];

    if (role === "Candidate") {
      applications = db.applications.find({ candidateId: userId });
    } else if (role === "Recruiter") {
      // Find all jobs posted by this recruiter
      const recruiterJobs = db.jobs.find({ postedBy: userId });
      const jobIds = recruiterJobs.map((j) => j._id);
      applications = db.applications.find().filter((app) => jobIds.includes(app.jobId));
    } else if (role === "Admin") {
      applications = db.applications.find();
    }

    const enrichedApps = applications.map((app) => {
      const job = db.jobs.findOne({ _id: app.jobId });
      const candidateUser = db.users.findOne({ _id: app.candidateId });
      const candidateDetails = db.candidates.findOne({ userId: app.candidateId });
      
      return {
        ...app,
        jobTitle: job ? job.title : "Unknown Position",
        companyName: job ? (db.recruiters.findOne({ userId: job.postedBy })?.company || "Tech Corp") : "Unknown Corp",
        candidateName: candidateUser ? candidateUser.name : "Anonymous Candidate",
        candidateEmail: candidateUser ? candidateUser.email : "",
        candidateSkills: candidateDetails ? candidateDetails.skills : [],
        candidateExperience: candidateDetails ? candidateDetails.experience : 0,
      };
    });

    return res.json(enrichedApps);
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// POST /api/rank_candidates (rank candidates for a specific job)
router.get("/rank_candidates", authenticateToken, authorizeRoles("Recruiter", "Admin"), (req: AuthenticatedRequest, res: any) => {
  try {
    const { jobId } = req.query;
    if (!jobId) return res.status(400).json({ error: "Job ID is required." });

    const job = db.jobs.findOne({ _id: jobId as string });
    if (!job) return res.status(404).json({ error: "Job posting not found." });

    const applications = db.applications.find({ jobId: jobId as string });
    
    const rankedCandidates = applications.map((app) => {
      const candUser = db.users.findOne({ _id: app.candidateId });
      const candDetails = db.candidates.findOne({ userId: app.candidateId });

      return {
        applicationId: app._id,
        candidateId: app.candidateId,
        name: candUser ? candUser.name : "Candidate",
        email: candUser ? candUser.email : "",
        skills: candDetails ? candDetails.skills : [],
        experience: candDetails ? candDetails.experience : 0,
        score: app.score,
        status: app.status,
        prediction: app.analysis?.prediction || "Applied",
        recommendation: app.analysis?.recommendation || "",
      };
    }).sort((a, b) => b.score - a.score); // Highest matching score first!

    return res.json({ jobId, jobTitle: job.title, rankings: rankedCandidates });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// PUT /api/applications (Status updates: shortlist/reject)
router.put("/applications", authenticateToken, authorizeRoles("Recruiter", "Admin"), (req: AuthenticatedRequest, res: any) => {
  try {
    const { id, status } = req.body;
    if (!id || !status) return res.status(400).json({ error: "Application ID and status are required." });

    const updated = db.applications.updateOne({ _id: id }, { status });
    if (!updated) return res.status(404).json({ error: "Application not found." });

    return res.json({ message: `Candidate successfully ${status.toLowerCase()}.` });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// GET /api/candidates (list candidates)
router.get("/candidates", authenticateToken, authorizeRoles("Recruiter", "Admin"), (req: AuthenticatedRequest, res: any) => {
  try {
    const candidates = db.candidates.find();
    const enriched = candidates.map((c) => {
      const user = db.users.findOne({ _id: c.userId });
      return {
        ...c,
        name: user ? user.name : "Unknown",
        email: user ? user.email : "",
      };
    });
    return res.json(enriched);
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// ==========================================
// 7. ANALYTICS & REPORTS (CHART DATA)
// ==========================================

// GET /api/analytics
router.get("/analytics", authenticateToken, (req: AuthenticatedRequest, res: any) => {
  try {
    const allCandidates = db.candidates.find();
    const allJobs = db.jobs.find();
    const allApps = db.applications.find();

    const shortlisted = allApps.filter((a) => a.status === "Shortlisted").length;
    const totalScore = allApps.reduce((sum, a) => sum + a.score, 0);
    const avgScore = allApps.length > 0 ? Math.round(totalScore / allApps.length) : 0;

    // Build skill category distribution
    const skillCounts: Record<string, number> = {
      Programming: 0,
      Frontend: 0,
      Backend: 0,
      Database: 0,
      "AI/ML": 0,
      Cloud_DevOps: 0,
    };

    allCandidates.forEach((cand) => {
      cand.skills.forEach((skill) => {
        const norm = skill.toLowerCase();
        if (["python", "java", "c++", "rust", "go", "typescript", "javascript"].includes(norm)) skillCounts.Programming++;
        if (["react", "angular", "vue", "html", "css", "tailwind"].includes(norm)) skillCounts.Frontend++;
        if (["node", "express", "flask", "django", "fastapi"].includes(norm)) skillCounts.Backend++;
        if (["mongodb", "postgresql", "mysql", "redis", "sqlite"].includes(norm)) skillCounts.Database++;
        if (["pytorch", "tensorflow", "scikit-learn", "nlp", "pandas", "numpy", "llm"].includes(norm)) skillCounts["AI/ML"]++;
        if (["aws", "gcp", "docker", "kubernetes", "terraform", "ci/cd"].includes(norm)) skillCounts.Cloud_DevOps++;
      });
    });

    const skillDistribution = Object.keys(skillCounts).map((key) => ({
      name: key,
      value: skillCounts[key] || 1, // seed at least 1 for display
    }));

    return res.json({
      totalCandidates: allCandidates.length,
      totalJobs: allJobs.length,
      totalApplications: allApps.length,
      shortlistedCandidates: shortlisted,
      averageScore: avgScore,
      skillDistribution,
      monthlyApplications: [
        { month: "Feb", apps: Math.round(allApps.length * 0.4) },
        { month: "Mar", apps: Math.round(allApps.length * 0.7) },
        { month: "Apr", apps: Math.round(allApps.length * 0.5) },
        { month: "May", apps: Math.round(allApps.length * 0.8) },
        { month: "Jun", apps: allApps.length },
      ],
      recruitmentFunnel: [
        { stage: "Applied", count: allApps.length },
        { stage: "Screened (Match > 60%)", count: allApps.filter((a) => a.score >= 60).length },
        { stage: "ML Recommended", count: allApps.filter((a) => a.analysis?.prediction === "Selected").length },
        { stage: "Shortlisted", count: shortlisted },
      ]
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// GET /api/reports (Admin summary and database list)
router.get("/reports", authenticateToken, authorizeRoles("Admin"), (req: any, res: any) => {
  try {
    const users = db.users.find().map(u => ({ _id: u._id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt, verified: u.verified }));
    const jobs = db.jobs.find();
    const applications = db.applications.find();

    return res.json({
      users,
      totalJobs: jobs.length,
      totalApplications: applications.length,
      dbMetrics: {
        usersSize: users.length,
        jobsSize: jobs.length,
        applicationsSize: applications.length,
        candidatesSize: db.candidates.find().length,
      }
    });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// DELETE /api/users (Admin can delete users)
router.delete("/users", authenticateToken, authorizeRoles("Admin"), (req: any, res: any) => {
  try {
    const { id } = req.query;
    if (!id) return res.status(400).json({ error: "User ID is required." });

    const user = db.users.findOne({ _id: id as string });
    if (!user) return res.status(404).json({ error: "User not found." });

    db.users.deleteOne({ _id: id as string });
    
    if (user.role === "Candidate") {
      db.candidates.deleteOne({ userId: id as string });
      db.applications.deleteMany({ candidateId: id as string });
    } else if (user.role === "Recruiter") {
      db.recruiters.deleteOne({ userId: id as string });
      const recruiterJobs = db.jobs.find({ postedBy: id as string });
      recruiterJobs.forEach(j => {
        db.jobs.deleteOne({ _id: j._id });
        db.applications.deleteMany({ jobId: j._id });
      });
    }

    return res.json({ message: "User and all associated data deleted successfully." });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

export default router;
