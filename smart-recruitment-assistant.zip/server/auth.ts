import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

const JWT_SECRET = process.env.JWT_SECRET || "smart-recruitment-assistant-super-secret-key-2026";

// Extended Express Request to include user context
export interface AuthenticatedRequest extends Request {
  user?: {
    _id: string;
    name: string;
    email: string;
    role: "Candidate" | "Recruiter" | "Admin";
  };
}

// 1. Password Security
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// 2. JWT Generation
export function signToken(payload: { _id: string; name: string; email: string; role: string }): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): any {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

// 3. Middlewares
export function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    res.status(401).json({ error: "Access Denied: No token provided." });
    return;
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    res.status(403).json({ error: "Access Denied: Invalid or expired token." });
    return;
  }

  req.user = decoded;
  next();
}

export function authorizeRoles(...roles: ("Candidate" | "Recruiter" | "Admin")[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      res.status(401).json({ error: "Access Denied: User not authenticated." });
      return;
    }

    if (!roles.includes(req.user.role)) {
      res.status(403).json({
        error: `Access Denied: Role '${req.user.role}' is not authorized to access this resource.`,
      });
      return;
    }

    next();
  };
}
