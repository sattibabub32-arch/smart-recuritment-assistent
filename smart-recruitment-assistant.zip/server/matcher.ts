/**
 * TF-IDF and Cosine Similarity Engine
 * Calculates keyword overlap and similarity scores between resumes and job requirements.
 */

// Simple English Stopwords to filter out during tokenization
const STOPWORDS = new Set([
  "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "arent", "as", "at",
  "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "can", "cant", "cannot",
  "could", "couldnt", "did", "didnt", "do", "does", "doesnt", "doing", "dont", "down", "during", "each", "few",
  "for", "from", "further", "had", "hadnt", "has", "hasnt", "have", "havent", "having", "he", "hed", "hell",
  "hes", "her", "here", "heres", "hers", "herself", "him", "himself", "his", "how", "hows", "i", "id", "ill",
  "im", "ive", "if", "in", "into", "is", "isnt", "it", "its", "itself", "lets", "me", "more", "most", "mustnt",
  "my", "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought", "our", "ours",
  "ourselves", "out", "over", "own", "same", "shant", "she", "shed", "shell", "shes", "should", "shouldnt",
  "so", "some", "such", "than", "that", "thats", "the", "their", "theirs", "them", "themselves", "then", "there",
  "theres", "these", "they", "theyd", "theyll", "theyre", "theyve", "this", "those", "through", "to", "too",
  "under", "until", "up", "very", "was", "wasnt", "we", "wed", "well", "were", "weve", "werent", "what", "whats",
  "when", "whens", "where", "wheres", "which", "while", "who", "whos", "whom", "why", "whys", "with", "wont",
  "would", "wouldnt", "you", "youd", "youll", "youre", "youve", "your", "yours", "yourself", "yourselves"
]);

// Tokenize and normalize text
export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, " ") // replace punctuation with spaces
    .split(/\s+/)
    .filter((token) => token.length > 1 && !STOPWORDS.has(token));
}

// Calculate term frequency of words in a document
export function getTermFrequency(tokens: string[]): Record<string, number> {
  const tf: Record<string, number> = {};
  for (const token of tokens) {
    tf[token] = (tf[token] || 0) + 1;
  }
  // Normalize term frequency
  const total = tokens.length;
  if (total > 0) {
    for (const token in tf) {
      tf[token] = tf[token] / total;
    }
  }
  return tf;
}

// Compute Cosine Similarity between two TF-IDF/TF representations
export function cosineSimilarity(vecA: Record<string, number>, vecB: Record<string, number>): number {
  const uniqueTerms = new Set([...Object.keys(vecA), ...Object.keys(vecB)]);
  
  let dotProduct = 0;
  let magnitudeA = 0;
  let magnitudeB = 0;

  for (const term of uniqueTerms) {
    const valA = vecA[term] || 0;
    const valB = vecB[term] || 0;

    dotProduct += valA * valB;
    magnitudeA += valA * valA;
    magnitudeB += valB * valB;
  }

  magnitudeA = Math.sqrt(magnitudeA);
  magnitudeB = Math.sqrt(magnitudeB);

  if (magnitudeA === 0 || magnitudeB === 0) {
    return 0;
  }

  return dotProduct / (magnitudeA * magnitudeB);
}

/**
 * Calculates a standard keyword overlap match score (0-100) between candidate skills
 * and required skills. Supports case-insensitive fuzzy matching.
 */
export function calculateSkillsMatch(candidateSkills: string[], requiredSkills: string[]): {
  score: number;
  matched: string[];
  missing: string[];
} {
  if (requiredSkills.length === 0) {
    return { score: 100, matched: [], missing: [] };
  }

  const normCandidate = candidateSkills.map(s => s.toLowerCase().trim());
  const matched: string[] = [];
  const missing: string[] = [];

  for (const reqSkill of requiredSkills) {
    const normReq = reqSkill.toLowerCase().trim();
    // Check for direct or substring matching
    const isMatched = normCandidate.some(cand => cand.includes(normReq) || normReq.includes(cand));
    if (isMatched) {
      matched.push(reqSkill);
    } else {
      missing.push(reqSkill);
    }
  }

  const score = Math.round((matched.length / requiredSkills.length) * 100);
  return { score, matched, missing };
}
